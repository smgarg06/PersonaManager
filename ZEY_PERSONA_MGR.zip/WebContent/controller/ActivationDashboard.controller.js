sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
		"sap/ui/core/Fragment"

], function(Controller, JSONModel, MessageBox, History, Fragment) {
	"use strict";

	var that;
	var oRouter;
	var token;

	jQuery.sap.require("sap.ui.core.routing.Router");
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.ActivationDashboard", {
		onInit: function() {
			that = this;
			that._oBusyDialog = new sap.m.BusyDialog();
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			var oVizFramePersonasIdentified = this.oVizFrame = this.getView().byId("idVizFramePersonasIdentified");
			oVizFramePersonasIdentified.setVizProperties({

				plotArea: {
					dataLabel: {
						visible: false
					},
					dataPoint: {
						stroke: {
							visible: false
						}
					},
					dataPointStyle: {
						"rules": [{
							"dataContext": {
								"Count": {
									min: 0,
									max: 8
								}
							},
							"properties": {
								"color": "#cccccc"
							},
							"displayName": "0-8"
						},{
							"dataContext": {
								"Count": {
									min: 8,
									max: 16
								}
							},
							"properties": {
								"color": "#999999"
							},
							"displayName": "8-16"
						},{
							"dataContext": {
								"Count": {
									min: 16,
									max: 32
								}
							},
							"properties": {
								"color": "#ffe600"
							},
							"displayName": "16-32"
						}],
						"others": {
							"properties": {
								"color": "#797878"
							},
							"displayName": "> 32"
						}
					}
				},
				legend: {
					visible: true,
					title: {
						visible: false
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: false,
					text: ''
				}
			});
			var oTooltipTreePersona = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipTreePersona.connect(this.getView().byId("idVizFramePersonasIdentified").getVizUid());
			var oVizFrameTCodes = this.oVizFrame = this.getView().byId("idVizFrameTCodes");
			oVizFrameTCodes.setVizProperties({
				plotArea: {
					dataLabel: {
						visible: false,
						position: "outside",
						alignment: "center"
					},
					dataPointStyle: {
						"rules": [{
							"dataContext": {
								"TcodeCount": {
									max: 8
								}
							},
							"properties": {
								"color": "#FFDB00"
							},
							"displayName": "Transactions Count < 9"
						}],
						"others": {
							"properties": {
								"color": "#797878"
							},
							"displayName": "Transactions Count > 9"
						}
					},
					gridline: {
						visible: false
					},
					dataPointSize: {
						min: 20,
						max: 20
					},
					gap: {
						groupSpacing: 0.5,
						barSpacing: 0.25
					}
				},

				legend: {
					visible: true,
					title: {
						visible: false
					}
				},
				valueAxis: {
					title: {
						visible: false
					},
					tooltip: {
						bodyMeasureValue: {
							color: "#ffffff"
						},
						visible: true,
						formatString: "1234"
					},
					label: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					},
					axisLine: {
						visible: false
					}
				},
				tooltip: {
					bodyMeasureValue: {
						color: "#ffffff"
					},
					visible: true,
					formatString: "1234"
				},
				title: {
					visible: false,
					text: ''
				}

			});
			var oTooltipBarTcode = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipBarTcode.connect(that.getView().byId("idVizFrameTCodes").getVizUid());

			var selectionParameterdata = {
				"PersonasIdentified": [],
				"TCodesIdentified": []
			};
			var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
			oModelSelectionParameter.setData(selectionParameterdata);
			that.getOwnerComponent().setModel(oModelSelectionParameter, "SelectionParameterModel");
			that.onLoadScreen1();

		},

		onAfterRendering: function() {

		},

		onLoadScreen1: function() {
			var oModel = that.getOwnerComponent().getModel("SelectionParameterModel");
			that.getView().byId("idVizFramePersonasIdentified").setBusy(true);
			that.getView().byId("idVizFrameTCodes").setBusy(true);
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");

			/***************** TCodes Identified **************/

			that.getView().byId("tcodesidentified").setBusy(true);

			dashboardModel.read("/AppsBasedSto3ResultSet", {
				urlParameters: {
					$select: 'Tcode,Totalcount',
					$format: 'json'
				},
				success: function(oData, response) {
					var results = oData.results;

					var tcodesIdentified = [];
					for (var i = 0; i < results.length; i++) {
						tcodesIdentified.push(results[i].Tcode);
					}

					var tcodesIdentifiedTemp = tcodesIdentified.filter(function onlyUnique(value, index, self) {
						return self.indexOf(value) === index;
					});
					tcodesIdentified = tcodesIdentifiedTemp;

					that.getView().byId("tcodesidentified").setText(tcodesIdentified.length);
					that.getView().byId("tcodesidentified").setBusy(false);

					var holder = {};

					results.forEach(function(d) {
						if (holder.hasOwnProperty(d.Tcode)) {
							holder[d.Tcode] = parseInt(d.Totalcount);
						} else {
							holder[d.Tcode] = parseInt(d.Totalcount);
						}
					});

					oModel.getData().TCodesIdentified = [];

					for (var prop in holder) {
						oModel.getData().TCodesIdentified.push({
							Tcode: prop,
							// Totalcount: parseInt(holder[prop])
							Totalcount: 20
						});
					}

					oModel.refresh();
					oModel.updateBindings();
					that.getView().byId("idVizFrameTCodes").setBusy(false);
				},
				error: function(oError) {

				}
			});

			/****************************************************/

			/***************** Personas Identified **************/

			that.getView().byId("personasidentified").setBusy(true);
			//		sap.ui.core.BusyIndicator.show();
			dashboardModel.read("/AppsBasedSto3ResultSet", {
				urlParameters: {
					$select: 'Businessgroupdescription,Lob,Totalcount',
					$format: 'json'
				},
				success: function(oData, response) {

					var results = oData.results;

					var personasIdentified = [];
					for (var i = 0; i < results.length; i++) {
						//temporary code
						if(results[i].Businessgroupdescription===""){
							results[i].Businessgroupdescription="Without Process Assignment(Standard)";
							}
						personasIdentified.push(results[i].Businessgroupdescription);
					}

					var personasIdentifiedTemp = personasIdentified.filter(function onlyUnique(value, index, self) {
						return self.indexOf(value) === index;
					});
					personasIdentified = personasIdentifiedTemp;

					that.getView().byId("personasidentified").setText(personasIdentified.length);
					that.getView().byId("personasidentified").setBusy(false);

					var holder = {};
					var vlist = {};
					var vLoblist = {};
					var aList = [];
					var tempList = {};
					results.forEach(function(d) {
						//temporary code
						if(d.Businessgroupdescription===""){
							d.Businessgroupdescription="Without Process Assignment(Standard)";
							}
						if (vLoblist.hasOwnProperty(d.Lob)) {
							vLoblist[d.Lob] = vLoblist[d.Lob] + "," + d.Businessgroupdescription;
							var temp = vLoblist[d.Lob];
							var aLoblist = [];
							aLoblist = temp.split(",");
							var uniqueItems = Array.from(new Set(aLoblist));
							vLoblist[d.Lob] = uniqueItems;
						} else {
							vLoblist[d.Lob] = d.Businessgroupdescription;

						}
					});
					tempList = vLoblist;

					results.forEach(function(d) {

						if (vlist.hasOwnProperty(d.Businessgroupdescription)) {

							vlist[d.Businessgroupdescription] = vlist[d.Businessgroupdescription] + "," + d.Lob;

							var temp = vlist[d.Businessgroupdescription];

							aList = temp.split(",");
							var uniqueItems = Array.from(new Set(aList));
							vlist[d.Businessgroupdescription] = uniqueItems;

						} else {
							vlist[d.Businessgroupdescription] = d.Lob;

						}
					});

					results.forEach(function(d) {

						if (holder.hasOwnProperty(d.Businessgroupdescription)) {
							holder[d.Businessgroupdescription] = holder[d.Businessgroupdescription] + 1;

						} else {
							holder[d.Businessgroupdescription] = 1;

						}
					});

					oModel.getData().PersonasIdentified = [];
				
					for (var prop in holder) {

						oModel.getData().PersonasIdentified.push({
							Businessgroupdescription: prop,
							Totalcount: parseInt(holder[prop]),
							Lob: 'Finance'
						});
					}
					
					oModel.refresh();
					oModel.updateBindings();
					that.getView().byId("idVizFramePersonasIdentified").setBusy(false);

				},
				error: function(oError) {

				}

			});

		},

		handleFormatSeconds: function(milliseconds) {

			var avgResponseTime;

			var seconds = Math.round(parseFloat(milliseconds) / 1000);

			if (seconds.toString().length < 3) {
				avgResponseTime = Math.round(seconds, 2) + " " + "secs";
			} else if (seconds.toString().length === 3) {
				avgResponseTime = Math.round((seconds / 60), 2) + " " + "mins";
			} else if (seconds.toString().length > 3) {
				avgResponseTime = Math.round(((seconds / 60) / 60), 2) + " " + "hrs";
			}

			if (isNaN(seconds)) {
				avgResponseTime = "";
			}

			return avgResponseTime;

		},

		onUpload: function(e) {
			var fileLoader = this.getView().byId("fileUploader");

			var fU = that.getView().byId("idfileUploader");
			var domRef = fU.getFocusDomRef();
			var file = domRef.files[0];
			var dublicateValue = [];
			try {
				if (file) {
					that._oBusyDialog.open();

					/****************To Fetch CSRF Token*******************/

					var sUrl = "/sap/opu/odata/sap/ZFIORI_PERSONAMGR_SRV/UpLoadExcelSet";
					$.ajax({
						url: sUrl,
						type: "GET",
						beforeSend: function(xhr) {
							xhr.setRequestHeader("X-CSRF-Token", "Fetch");
						},
						success: function(data, textStatus, XMLHttpRequest) {
							var oToken = XMLHttpRequest.getResponseHeader('X-CSRF-Token');
							var oHeaders = {
								"x-csrf-token": oToken
							};

							/******************************************************/

							/*******************To Upload File************************/

							var oURL = "/sap/opu/odata/sap/ZFIORI_PERSONAMGR_SRV/UpLoadExcelSet";
							$.ajax({
								type: 'POST',
								url: oURL,
								headers: oHeaders,
								cache: false,
								contentType: ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
								processData: false,
								data: file,
								success: function(data) {
									sap.m.MessageBox.information("File has been uploaded");
									that._oBusyDialog.close();
									that.onLoadScreen1();
								},
								error: function(oError) {
									sap.m.MessageBox.error("Error during file upload");
									that._oBusyDialog.close();
								}
							});
						},
						error: function(oError) {
							sap.m.MessageBox.error("Error while fetching token");
							that._oBusyDialog.close();
						}
					});
				}
			} catch (Exception) {
				sap.m.MessageBox.error("File upload failed");
				that._oBusyDialog.close();
			}

		},

		onGoToAdminConfigDashboard: function() {
			oRouter.navTo("AdminConfigDashboard");
		},

		onGoToList: function() {
			oRouter.navTo("PersonaList");
		},

		onViewDetailsTCodes: function() {
			oRouter.navTo("TCodeList");
		},
		onPrint:function(){
				oRouter.navTo("Reports");
		},

		onViewDetailsPersonasIdentified: function() {

			oRouter.navTo("PersonaList");
		},
			onSetting:function(oEvent){
/*var oView = that.getView();
			var oDialog = oView.byId("idSettings");
			if (!oDialog) {
			
				oDialog = sap.ui.xmlfragment(oView.getId(), "fpm.FIORI_Persona_Manager.fragment.settings", this);
				oView.addDependent(oDialog);
			}
			oDialog.open();			
		},
			onCloseFilterDialog: function (oEvent) {
		
			that.getView().byId("idSettings").close();*/
			
				var oButton = oEvent.getSource();
			// create popover
			if (!this._oPopoverT) {
				Fragment.load({
					name: "fpm.FIORI_Persona_Manager.fragment.rPopoverT",
					controller: this
				}).then(function (pPopover) {
					this._oPopoverT = pPopover;
					this.getView().addDependent(this._oPopoverT);

					this._oPopoverT.openBy(oButton);
				}.bind(this));
			} else {
				this._oPopoverT.openBy(oButton);
			}

		},
			handleCloseButtonT: function () {

			this._oPopoverT.close();
		},
		
		handleApplyButtonT :function () {

			this._oPopoverT.close();
		}

	});
});