sap.ui.define(["sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/suite/ui/microchart/InteractiveBarChartBar",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox" // ,
	// "fpm/FIORI_Persona_Manager/extlibs/jspdf.debug",
	// "fpm/FIORI_Persona_Manager/extlibs/jspdf.plugin.autotable"

], function(Controller, Filter, FilterOperator, InteractiveBarChartBar, JSONModel, MessageBox) {
	"use strict";

	var that;
	var oRouter;
	var fioriAppsSelected;
	var fioriAppsSelectedObjectList;

	jQuery.sap.require("sap.ui.core.routing.Router");
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.ViewCart", {
		onInit: function() {
			that = this;
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("ViewCart").attachPatternMatched(this.onLoadCartData, this);

		},

		onLoadCartData: function() {
			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			for(var i=0;i<oModel.getData().AddedCart.length;i++){
				if((oModel.getData().AddedCart[i].TransProcTime).indexOf("mins")===-1){
				oModel.getData().AddedCart[i].Fioriproctime = that.handleFormatSeconds((oModel.getData().AddedCart[i].TransProcTime -((oModel.getData().AddedCart[i].TransProcTime * 20/100))).toFixed());
				oModel.getData().AddedCart[i].TransProcTime=that.handleFormatSeconds((oModel.getData().AddedCart[i].TransProcTime));
				}
			}
			oModel.refresh();
			oModel.updateBindings();

		},
			onHome: function() {

			oRouter.navTo("ActivationDashboard");
			},

		onGoToAdminConfigDashboard: function() {

			//oRouter.navTo("AssignAdminDashboard");
			//window.history.back();
			
			oRouter.navTo("AssignAdminDashboard", {
				businessGroupDescription: that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").getProperty("/BusinessGroupDescription")
			});

		},

		onManageOrder: function() {
			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			oModel.setProperty('/createdOrderId', null);
			oRouter.navTo("ManageOrders");
		},
		
		onCheckoutPress : function(oEvent)
		{
			var oButton = oEvent.getSource();
			this.byId("actionSheetOreder").openBy(oButton);
		},

		onCheckout: function() {

			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");

			var oEntry = {};
			oEntry.ORDERID = '';
			// oEntry.urlParameters= {
		 //       $expand: 'OrderstoDetails'
		 //   };
			oEntry.OrderstoDetails=oModel.getData().AddedCart;
			//oEntry.CARTITM = JSON.stringify(oModel.getData().AddedCart);

			dashboardModel.create("/OrderCartSet", oEntry, {
				success: function(oData,oResponse) {
					MessageBox.success("Order Created Successfully");
					oModel.setProperty('/createdOrderId',oData.ORDERID);
					oModel.getData().AddedCart = [];
					oModel.getData().SelectedApps=oModel.getData().AddedCart.length;
					fioriAppsSelectedObjectList=[];
					fioriAppsSelected=[];
					oModel.refresh();
					oModel.updateBindings();
					oRouter.navTo("ManageOrders");
				},
				error: function() {
					MessageBox.error("Order cannot be created due to internal error");
				}
			});

		},
		
		selectOrders : function()
		{
				var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
				dashboardModel.read("/OrderCartSet", {
				urlParameters: {
					$expand: 'OrderstoDetails',
					$format: 'json'
				},
				success: function(oData) {
					var orderDetails = oData.results[0].OrderstoDetails.results;
					
				},
				error: function() {
					//MessageBox.error("Order cannot be created due to internal error");
				}
			});
				if (!this._openExtOrderDialog) {
				this._openExtOrderDialog = sap.ui.xmlfragment(this.getView().getId(),"fpm.FIORI_Persona_Manager.fragment.SelectOrders", this);
				this._openExtOrderDialog.setModel(dashboardModel);
				this.getView().addDependent(this._openExtOrderDialog);
				
			}
			this._openExtOrderDialog.open();
		},
		
		onConfirmApps : function(evt)
		{
			debugger;
			var data = [];
				// var that  = this;
					var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
			data  = JSON.parse(evt.getSource().getParent().getContent()[0].getContent()[1].getSelectedItem().data().textData);
			
				var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			var sKey = evt.getSource().getParent().getContent()[0].getContent()[1].getSelectedKey();
			for(var k = 0 ; k < oModel.getData().AddedCart.length;k++)
			{
				oModel.getData().AddedCart[k].OrderId=sKey;
				data.push(oModel.getData().AddedCart[k]);
			}
		
			var oEntry = {};
			oEntry.ORDERID = sKey;
			oEntry.OrderstoDetails= data;
			// oEntry.urlParameters= {
		 //       $expand: 'OrderstoDetails'
		 //   };
			dashboardModel.update("/OrderCartSet('"+sKey+"')", oEntry, {
				success: function() {
					MessageBox.success("Order has been changed Successfully");
					oModel.getData().AddedCart = [];
					oModel.refresh();
					oModel.updateBindings();
					that._openExtOrderDialog.close();
				},
				error: function() {
					MessageBox.error("Order cannot be created due to internal error");
				}
			});
			/*dashboardModel.update("/OrderCartSet(ORDERID='"+sKey+"')", oEntry,null, {
				success: function() {
					that._openExtOrderDialog.close();
					MessageBox.success("Order Created Successfully");
					oModel.getData().AddedCart = [];
					oModel.refresh();
					oModel.updateBindings();
				},
				error: function() {
						that._openExtOrderDialog.close();
					MessageBox.error("Order cannot be updated due to internal error");
				}
			});*/
		},

		_printReport: function() {
			var doc = new jsPDF('p', 'pt', 'letter');
			var stabId = document.getElementById(this.getView().byId("appDescription").getId()).children[2].getAttribute('id');
			var tabsId = doc.autoTableHtmlToJson(document.getElementById(stabId));
			doc.autoTable(tabsId.columns, tabsId.data, {
				startY: 50,
				pageBreak: 'auto',
				tableWidth: 'auto',
				styles: {
					overflow: 'linebreak',
					columnWidth: 'wrap'
				},
				headStyles: {
					0: {
						halign: 'center',
						fillColor: [0, 255, 0]
					}
				},
				beforePageContent: function(data) {
					doc.setTextColor('#2e2e38');
					doc.text("Assessment Report - Fiori Apps List", 40, 40);
				}
			});
			doc.save('Assessment Report' + '.pdf');
		},

		removeItem: function(oEvent) {
			var oSrc = oEvent.getSource();
			var sIdx = oSrc.getBindingContext("AssignAdminSelectionParameterModel").getPath().split("/").pop();
			oSrc.getModel("AssignAdminSelectionParameterModel").getProperty("/AddedCart").splice(sIdx, 1);
			oSrc.getModel("AssignAdminSelectionParameterModel").refresh(true);
			MessageBox.show('Items removed');
		},
		
		onCartDeleteItem:function(oEvent){
			var sKey = oEvent.getSource().getCustomData()[0].getKey();
			//remove item from model
            	var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
				for(var i=oModel.getData().AddedCart.length-1; i >= 0; i--){
					if(sKey===oModel.getData().AddedCart[i].FioriAppId){
						oModel.getData().AddedCart.splice(i,1);
						
					}
				}
				var cartItem= oModel.getData().AddedCart;
				var unique = [...new Set(cartItem.map(item => item.FioriAppId))];
				oModel.getData().SelectedApps=unique.length;
				oModel.refresh();
				oModel.updateBindings();
				oEvent.getSource().removeCustomData(sKey);
				
			MessageBox.show('Items removed');
		},
		
		onCheckBoxSelected:function(oEvent){
			var selStatus = oEvent.getSource().getSelected();
            var delBtnRef=this.getView().byId("appDescription").getHeaderToolbar().getContent()[3];
            delBtnRef.removeAllCustomData();
            if(selStatus===true){
            	delBtnRef.setEnabled(true);
            	delBtnRef.addCustomData(new sap.ui.core.CustomData({"key":oEvent.getSource().getText()}));
            }else{
            	delBtnRef.setEnabled(false);
            	delBtnRef.removeCustomData(srcItemId);
            	
            	
            }
		},
		handleFormatSeconds: function(milliseconds) {

			var avgResponseTime;

			var seconds = Math.round(parseFloat(milliseconds) / 1000);

			if (seconds.toString().length < 3) {
				avgResponseTime = Math.round(seconds, 2) + " " + "secs";
			} else if (seconds.toString().length === 3) {
				avgResponseTime = Math.round((seconds / 60), 2) + " " + "mins";
			} else if (seconds.toString().length > 3) {
				avgResponseTime = Math.round(((seconds / 60) / 60), 2) + " " + "hrs";
			}

			if (isNaN(seconds)) {
				avgResponseTime = "";
			}

			return avgResponseTime;

		},

		onProvision: function() {
			MessageBox.error("Please select at least one user to proceed");
		}

	});
});