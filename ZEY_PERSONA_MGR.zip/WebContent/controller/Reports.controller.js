sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var that;
	var PersonaDetList = {};
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.Reports", {

		onInit: function() {
			that = this;

			var selectionParameterdata = {
				"FioriReadiness": [],
				"FioriApps": [],
				"PieValue": [],
				"StackedValue": [],
				"OrderWiseHourSaving": [],
				"FioriAppsCount":0,
				"PersonaCount":0,
				"OrdersCount":0,
				"TransactionCount":0,
				"StdTcodePercentage":0,
				"cusTcodePercentage":0,
				"mediumUsage":0,
				"highUsage":0,
				"overallFioriApps":0
			};
			var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
			oModelSelectionParameter.setData(selectionParameterdata);
			that.getOwnerComponent().setModel(oModelSelectionParameter, "ReportModel");

			var oVizFrameReadinessChart = this.oVizFrame = this.getView().byId("fioriReadinessChart");
			oVizFrameReadinessChart.setVizProperties({

				plotArea: {
					gridline: {
						visible: false
					},
					dataLabel: {
						visible: true,
						showTotal: true,
						style: {
							color: 'rgb(255, 192, 0) '
						}
					},
					dataPoint: {
						stroke: {
							visible: false
						}
					},
					dataPointStyle: {
						"rules": [{
							"dataContext": {
								"MeasureNamesDimension": "StandardTCodes"
							},
							"properties": {
								"color": "rgb(255,217,102)"
							},
							"displayName": "Standard TCodes"
						}, {
							"dataContext": {
								"MeasureNamesDimension": "ZTCodes"
							},
							"properties": {
								"color": "rgb(165,165,165)"
							},
							"displayName": "Z TCodes"
						}],
						"others": {
							"dataContext": {
								"MeasureNamesDimension": "StandardFioriApps"
							},
							"properties": {
								"color": "rgb(237, 126, 48)"
							},
							"displayName": "Standard Fiori Apps"
						}

					}
				},
				legend: {
					visible: true,
					title: {
						visible: true
					},
					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: 'Detailed Fiori Readiness Report',
					style: {
						color: 'rgb(255, 192, 0) '
					}
				}
			});
			var sSVG=oVizFrameReadinessChart.exportToSVGString({                  // UI5 predefined method
			  width: 800,
			  height: 600
			});	
			var oCanvasHTML = document.createElement("canvas");        // Create canvas element
			//canvg(oCanvasHTML, sSVG); 
			var oTooltip2 = new sap.viz.ui5.controls.VizTooltip({});
			oTooltip2.connect(this.getView().byId("fioriReadinessChart").getVizUid());

			var oVizFrameFioriApps = this.oVizFrame = this.getView().byId("fioriAppCountChart");
			oVizFrameFioriApps.setVizProperties({

				plotArea: {
					gridline: {
						visible: false
					},
					dataLabel: {
						visible: true,
						showTotal: true,
						style: {
							color: 'rgb(255, 192, 0) '
						}
					},
					dataPoint: {
						stroke: {
							visible: false
						}
					},
					dataPointStyle: {
						"rules": [{
							"dataContext": {
								"MeasureNamesDimension": "FioriAppsCount"
							},
							"properties": {
								"color": "rgb(237,125,49)"
							},
							"displayName": "Fiori Apps Count"
						}],
						"others": {
							"dataContext": {
								"MeasureNamesDimension": "TransactionsCount"
							},
							"properties": {
								"color": "rgb(132, 60, 12)"
							},
							"displayName": "Transactions Count"
						}

					}
				},
				legend: {
					visible: true,
					title: {
						visible: true
					},
					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					}
				},
				valueAxis: {
					title: {
						visible: false
					},
					color: 'rgb(255, 192, 0) '
				},
				categoryAxis: {
					title: {
						visible: true,
						text: 'Orders',
						style: {
							color: 'rgb(255, 192, 0) '
						}
					},
					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				title: {
					visible: false,
					text: 'Fiori App Count vs Transactions Used per Order ',
					style: {
						color: 'rgb(255, 192, 0) '
					}
				}
			});

			var oTooltip1 = new sap.viz.ui5.controls.VizTooltip({});
			oTooltip1.connect(this.getView().byId("fioriAppCountChart").getVizUid());

			// /*	/****************************** Anubhuti *************************/

			// 	var oVizFrameFrequency = this.oVizFrameFrequency = this.getView().byId("idChartFrequencyLob");
			// 	oVizFrameFrequency.setVizProperties({
			// 		isScrollable: false,
			// 		legend: {
			// 			visible: true,
			// 			title: {
			// 				visible: true
			// 			},
			// 			label: {
			// 				style: {
			// 					color: 'rgb(255, 192, 0) '
			// 				}
			// 			}
			// 		},
			// 		legendGroup: {
			// 			layout: {
			// 				position: 'bottom'
			// 			},
			// 			linesOfWrap: 3
			// 		},
			// 		categoryAxis: {
			// 			title: {
			// 				visible: true
			// 			}
			// 		},
			// 		title: {
			// 			visible: true,
			// 			text: "Heavily used Business Process % usage across Line of Business",
			// 			style: {
			// 				color: 'rgb(255, 192, 0) '
			// 			},
			// 			layout: {
			// 				maxHeight: 0.2
			// 			}
			// 		},
			// 		plotArea: {
			// 			dataLabel: {
			// 				visible: true,
			// 				type: "value"
			// 			},
			// 			colorPalette: ["sapUiChartPaletteSemanticCritical", '#FFA500', '#2c6ab0', '#808080', '#cccccc']
			// 		},
			// 		tooltip: {
			// 			bodyMeasureValue: {
			// 				type: "valueAndPercentage"
			// 			},
			// 			visible: true,
			// 			formatString: "1234"
			// 		},
			// 		interaction: {
			// 			selectability: {
			// 				mode: ""
			// 			}
			// 		}
			// 	});
			// 	var oTooltipPieLob = new sap.viz.ui5.controls.VizTooltip({});
			// 	oTooltipPieLob.connect(that.getView().byId("idChartFrequencyLob").getVizUid());*/

			/////////// Stacked Chart
			var oVizFrameFioriAppsStacked = this.oVizFrame = this.getView().byId("fioriAppCountChart1");
			oVizFrameFioriAppsStacked.setVizProperties({

				plotArea: {
					gridline: {
						visible: false
					},
					dataLabel: {
						visible: true,
						showTotal: true
					},
					dataPoint: {
						stroke: {
							visible: false
						}
					},
					dataPointStyle: {
						"rules": [{
							"dataContext": {
								"MeasureNamesDimension": "ZTCodes"
							},
							"properties": {
								"color": "rgb(255, 192, 0)"
							},
							"displayName": "Z TCodes"
						}],
						"others": {
							"dataContext": {
								"MeasureNamesDimension": "StandardTCodes"
							},
							"properties": {
								"color": "rgb(237, 125, 49)"
							},
							"displayName": "Standard TCodes"
						}

					}
				},
				legend: {
					isScrollable: false,
					visible: true,
					title: {
						visible: true
					},
					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					}
				},
				valueAxis: {
					title: {
						visible: false
					},
					color: 'rgb(255, 192, 0) '
				},
				categoryAxis: {
					title: {
						visible: true,
						text: '',
						style: {
							color: 'rgb(255, 192, 0) '
						}
					},
					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				title: {
					visible: false,
					text: 'Fiori App Count vs Transactions Used per Order ',
					style: {
						color: 'rgb(255, 192, 0) '
					}
				}
			});

			var oTooltipStacked = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipStacked.connect(this.getView().byId("fioriAppCountChart1").getVizUid());

			/****************************** Anubhuti *************************/
			var oVizFrameFrequency = this.oVizFrameFrequency = this.getView().byId("idChartFrequencyLob");
			oVizFrameFrequency.setVizProperties({
				legend: {
					visible: true,
					title: {
						visible: true
					},
					isScrollable: false,

					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					},
					linesOfWrap: 2
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: false,
					text: "Heavily used Business Process usage across Line of Business",
					style: {
						color: 'rgb(255, 192, 0) ',
						fontSize: "13px"
					},
					layout: {
						maxHeight: 0.2
					}
				},
				plotArea: {
					dataLabel: {
						visible: true,
						showTotal: true,
						type: "value",
						style: {
						color: 'rgb(255, 192, 0) ',
						fontSize: "13px"
					}
					},
					colorPalette: ["sapUiChartPaletteSemanticCritical", '#333333', '#ffe600', '#ffffff', '#cccccc', '#999999', '#52575D',
						'sapUiChartPaletteSemanticCriticalLight3', 'sapUiChartPaletteSemanticNeutral', 'sapUiChartPaletteSemanticCriticalDark2',
						'#FFD000'
					]
				},
				tooltip: {
					bodyMeasureValue: {
						type: "valueAndPercentage"
					},
					visible: true,
					formatString: "1234"
				}
			});
			var oTooltipPieLob = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipPieLob.connect(that.getView().byId("idChartFrequencyLob").getVizUid());

			/******* Souvik *******/

			var oVizFrameOrderWiseChart = this.oVizFrame = this.getView().byId("fioriOrderWiseChart");
			oVizFrameOrderWiseChart.setVizProperties({

				plotArea: {
					gridline: {
						visible: false
					},
					dataLabel: {
						visible: true,
						showTotal: true,
						style: {
							color: 'rgb(255, 192, 0) '
						}
					},
					dataPoint: {
						stroke: {
							visible: false
						}
					},
					dataPointStyle: {
						"rules": [],
						"others": {
							"dataContext": {
								"MeasureNamesDimension": "Orders"
							},
							"properties": {
								"color": "rgb(237, 125, 49)"
							},
							"displayName": "Orders"
						}

					}
				},
				legend: {
					visible: true,
					title: {
						visible: true
					},
					label: {
						style: {
							color: 'rgb(255, 192, 0) '
						}
					}
				},
				legendGroup: {
					layout: {
						position: 'bottom'
					}
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: 'Order wise Hour Saving with Fiori Applications',
					style: {
						color: 'rgb(255, 192, 0) '
					}
				}
			});

			var oTooltipArea = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipArea.connect(this.getView().byId("fioriOrderWiseChart").getVizUid());
			/************************Raghu*******************/
			var tcodes=that.getOwnerComponent().getModel("SelectionParameterModel").getData().TCodesIdentified;
			//var filterByValue=tcodes.filter(item => item.Tcode.startsWith('Z'))
			var ztcodes=tcodes.filter(item => item.Tcode.startsWith('Z'));
			var ytcodes=tcodes.filter(item => item.Tcode.startsWith('Y'));
			var stdtcodeCount=tcodes.length-(ztcodes.length+ytcodes.length);
			var calPercentage=function(occ, total){
				var res= (occ / total ) * 100;
				return res.toFixed();
			};
			var tcodesCount=tcodes.length;
			var custTcodeCount=ztcodes.length+ytcodes.length;
			var oModel = that.getOwnerComponent().getModel("ReportModel");
			oModel.getData().StdTcodePercentage=calPercentage(stdtcodeCount, tcodesCount);
			oModel.getData().CusTcodePercentage=calPercentage(custTcodeCount, tcodesCount);
			
			that.onLoadDetailedFioriReadiness();
			that.onLoadPersonaList();
		},

		onLoadDetailedFioriReadiness: function() {

			var oModel = that.getOwnerComponent().getModel("ReportModel");
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");

			that.getView().byId("idChartFrequencyLob").setBusy(true);
			that.getView().byId("fioriAppCountChart1").setBusy(true);
			that.getView().byId("fioriAppCountChart").setBusy(true);

			dashboardModel.read("/AppsBasedSto3ResultSet", {
				urlParameters: {
					$select: 'Tcode,Lob,Totalcount,Businessgroupdescription,Appid,Leastused,Mostused',
					$format: 'json'
				},
				success: function(oData, response) {

					var results = oData.results;
					PersonaDetList = oData.results;

					var vLoblist = {};
					var vBglist = {};
					var iHighUsage=0;
                    var iMediumUsage=0;
                    var aFioriApps=[];
					results.forEach(function(e) {

						if (vBglist.hasOwnProperty(e.Businessgroupdescription)) {
							vBglist[e.Businessgroupdescription] = vBglist[e.Businessgroupdescription] + "," + e.Tcode;
							var temp1 = vBglist[e.Businessgroupdescription];
							var aLoblist1 = [];
							aLoblist1 = temp1.split(",");
							var uniqueItems1 = Array.from(new Set(aLoblist1));
							vBglist[e.Businessgroupdescription] = uniqueItems1;
						} else {
							vBglist[e.Businessgroupdescription] = e.Tcode;

						}
						if(e.Leastused==="X"){
							iMediumUsage=iMediumUsage+1;
						}else{
							iHighUsage=iHighUsage+1;
						}
						if(aFioriApps.indexOf(e.Appid)===-1){ aFioriApps.push(e.Appid) };
					});

					for (var i = 0; i < Object.keys(vBglist).length; i++) {
						var stdTcode = 0;
						var customTCodes = 0;
						for (var j = 0; j < vBglist[Object.keys(vBglist)[i]].length; j++) {
							if (vBglist[Object.keys(vBglist)[i]][j] === "Z" || vBglist[Object.keys(vBglist)[i]][j] === "Y") {
								customTCodes = customTCodes + 1;
							} else {
								stdTcode = stdTcode + 1;
							}
						}

						oModel.getData().StackedValue.push({
							"Series": Object.keys(vBglist)[i],
							"StandardTCodes": stdTcode,
							"ZTCodes": customTCodes
						});

					}
					oModel.getData().mediumUsage= iMediumUsage/oData.results.length * 100;
					oModel.getData().highUsage=iHighUsage/oData.results.length * 100;
					oModel.getData().overallFioriApps=aFioriApps.length;

					results.forEach(function(d) {

						if (vLoblist.hasOwnProperty(d.Lob)) {
							vLoblist[d.Lob] = vLoblist[d.Lob] + "," + d.Tcode;
							var temp = vLoblist[d.Lob];
							var aLoblist = [];
							aLoblist = temp.split(",");
							var uniqueItems = Array.from(new Set(aLoblist));
							vLoblist[d.Lob] = uniqueItems;
						} else {
							vLoblist[d.Lob] = d.Tcode;

						}
					});
					for (var i = 0; i < Object.keys(vLoblist).length; i++) {

						oModel.getData().PieValue.push({
							Lob: Object.keys(vLoblist)[i],

							Tcode: vLoblist[Object.keys(vLoblist)[i]].length
						});

					}

					oModel.refresh();
					oModel.updateBindings();

					that.getView().byId("idChartFrequencyLob").setBusy(false);
					that.getView().byId("fioriAppCountChart1").setBusy(false);

				},
				error: function(oError) {
					that.getView().byId("idChartFrequencyLob").setBusy(false);
					that.getView().byId("fioriAppCountChart1").setBusy(false);
					that.getView().byId("fioriAppCountChart").setBusy(false);
				}

			});

			dashboardModel.read("/OrderCartSet", {
				urlParameters: {
					$format: 'json'
				},
				success: function(oData) {
					for (var l = 0; l < oData.results.length; l++) {

						var oModel = that.getOwnerComponent().getModel("ReportModel");

						var orderId = oData.results[l].ORDERID;

						var vCartItems = JSON.parse(oData.results[l].CARTITM);

						var AppCount = vCartItems.length;
						var vBglist = {};

						PersonaDetList.forEach(function(e) {

							if (vBglist.hasOwnProperty(e.Appid)) {
								vBglist[e.Appid] = vBglist[e.Appid] + "," + e.Tcode;
								var temp1 = vBglist[e.Appid];
								var aLoblist1 = [];
								aLoblist1 = temp1.split(",");
								var uniqueItems1 = Array.from(new Set(aLoblist1));
								vBglist[e.Appid] = uniqueItems1;
							} else {
								vBglist[e.Appid] = e.Tcode;

							}
						});
						var TcodeCount = 0;
						//line inserted by Raghu
						var personaByOrderArray=[];
						for (var k = 0; k < vCartItems.length; k++) {
							var appid = "";
							appid = Object.values(vCartItems)[k].Appid;
							if (vBglist.hasOwnProperty(appid)) {

								TcodeCount = TcodeCount + vBglist[appid].length;
							}
							//line inserted by Raghu
							if(personaByOrderArray.indexOf(vCartItems[k].BusinessGroupDescription) === -1){
								personaByOrderArray.push(vCartItems[k].BusinessGroupDescription);
							}
						}
						
						
						
						var personaCntByOrder=personaByOrderArray.length;
						
						oModel.getData().FioriApps.push({
							Series: orderId,
							FioriAppsCount: AppCount,
							TransactionsCount: TcodeCount,
							PersonaCount:personaCntByOrder
						});
						oModel.getData().FioriAppsCount=oModel.getData().FioriAppsCount+AppCount;
                        oModel.getData().PersonaCount=oModel.getData().PersonaCount+personaCntByOrder;
                        oModel.getData().OrdersCount++;
                        oModel.getData().TransactionCount=oModel.getData().TransactionCount+TcodeCount;
					}
					oModel.refresh();
					oModel.updateBindings();
					that.getView().byId("fioriAppCountChart").setBusy(false);
				},
				error: function() {
					that.getView().byId("fioriAppCountChart").setBusy(false);
				}
			});

			//	var oModel = that.getOwnerComponent().getModel("ReportModel");
			oModel.getData().FioriReadiness = [{
				"Series": "Persona1 Lob1",
				"StandardTCodes": 250,
				"StandardFioriApps": 35,
				"ZTCodes": 10
			}, {
				"Series": "Persona1 Lob2",
				"StandardTCodes": 120,
				"StandardFioriApps": 20,
				"ZTCodes": 5
			}, {
				"Series": "Persona2 Lob1",
				"StandardTCodes": 160,
				"StandardFioriApps": 20,
				"ZTCodes": 10
			}, {
				"Series": "Persona2 Lob2",
				"StandardTCodes": 70,
				"StandardFioriApps": 25,
				"ZTCodes": 5
			}];

			/*	oModel.getData().PieValue = [{
					"Series": "Supply Chain",
					"Values": 350
				}, {
					"Series": "Sourcing & Procurement",
					"FioriAppsCount": 300,
					"Values": 300
				}, {
					"Series": "Finance",
					"FioriAppsCount": 19,
					"Values": 150
				}, {
					"Series": "Asset Management",
					"FioriAppsCount": 4,
					"Values": 200
				}];*/
			/*	oModel.getData().StackedValue = [{
				"Series": "Persona 4",
				"ZTCodes": 50,
				"StandardTCodes": 250

			}, {
				"Series": "Persona 3",
				"ZTCodes": 10,
				"StandardTCodes": 230

			}, {
				"Series": "Persona 2",
				"ZTCodes": 30,
				"StandardTCodes": 46

			}, {
				"Series": "Persona 1",
				"ZTCodes": 10,
				"StandardTCodes": 90

			}];
*/
			/*	oModel.getData().FioriApps = [{
				"Series": "90000ABCD1",
				"FioriAppsCount": 4,
				"TransactionsCount": 10
			}, {
				"Series": "90000ABCD2",
				"FioriAppsCount": 20,
				"TransactionsCount": 32
			}, {
				"Series": "90000ABCD2",
				"FioriAppsCount": 19,
				"TransactionsCount": 34
			}, {
				"Series": "90000ABCD3",
				"FioriAppsCount": 4,
				"TransactionsCount": 12
			}, {
				"Series": "90000ABCD4",
				"FioriAppsCount": 3,
				"TransactionsCount": 12
			}];
*/
			oModel.getData().OrderWiseHourSaving = [{
				"Series": 'Persona1 Lob1 9000XXXX',
				"Orders": 10
			}, {
				"Series": 'Persona1 Lob2 9000XXXX',
				"Orders": 12
			}, {
				"Series": 'Persona2 Lob2 9000XXXX',
				"Orders": 5
			}, {
				"Series": 'Persona1 Lob3 9000XXXX',
				"Orders": 15
			}, {
				"Series": 'Persona1 Lob4 9000XXXX',
				"Orders": 8
			}];

			oModel.refresh();
			oModel.updateBindings();
		},
		
		onDownload:function(oEvent){
			
			//var hContent = '<html><head></head><body>';
			//var bodyContent = document.getElementById("container-FIORI_Persona_Manager---Reports--reportObjectPageId");
			//var closeContent = "</body></html>";
			//var htmlpage = hContent + bodyContent.outerHTML + closeContent;

			// var win = window.open("", "PrintWindow");
			// window.document.write(bodyContent.outerHTML);
			// win.print();
			// win.stop();
			
			//window.print(bodyContent.outerHTML);
			
			// var oVizframe = this.getView().byId("reportObjectPageId");        // access chart UI element
			// var sSVG = oVizFrame.exportToSVGString({                  // UI5 predefined method
			//   width: 800,
			//   height: 600
			// });	
			// var oCanvasHTML = document.createElement("canvas");        // Create canvas element
			// canvg(oCanvasHTML, sSVG);      // use library canvg to place SVG content on the canvas
			
			// var sImageData = oCanvasHTML.toDataURL("image/png");  // Get data URI in PNG or JPEG
			// // Create PDF using library jsPDF
			// var oPDF = new jsPDF();
			// oPDF.addImage(sImageData, 'PNG', 15, 40, 180, 160)
			// oPDF.save("test.pdf");     // PDF file name
			
			
			// var page=document.getElementById('container-FIORI_Persona_Manager---Reports--reportObjectPageId');
			// html2pdf().from(page).save();
			
			// html2canvas(document.getElementById('container-FIORI_Persona_Manager---Reports--reportObjectPageId'), {
   //           onrendered:function(canvas) {

   //               //Returns the image data URL, parameter: image format and clarity (0-1)
   //               var pageData = canvas.toDataURL('image/jpeg', 1.0);

   //               //Default vertical direction, size ponits, format a4[595.28,841.89]
   //               var pdf = new jsPDF('', 'pt', 'a4');

   //               //Two parameters after addImage control the size of the added image, where the page height is compressed according to the width-height ratio column of a4 paper.
   //               pdf.addImage(pageData, 'JPEG', 0, 0, 595.28, 592.28/canvas.width * canvas.height );

   //               pdf.save('stone.pdf');

   //           }
   //       });
				
				
	  var element = document.getElementById('container-FIORI_Persona_Manager---Reports--reportObjectPageId');
	  
	  var doc_width = 16; 
	  var doc_height = 11.69;
	  var opt = {
			  margin:       0,
			  filename:     'myfile.pdf',
			  image:        { type: 'jpeg', quality: 0.98 },
			  html2canvas:  { scale: 2 },
			  jsPDF:        { unit: 'in', format: [doc_width,doc_height], orientation: 'portrait' }
			};
			 
			// New Promise-based usage:
			html2pdf().set(opt).from(element).save();
			 
			
					
		},
		
		onLoadPersonaList: function() {
			var selectionParameterdata = {
				"ListView": [],
				"PieValue": [],
				"lobCount":0,
				"personaCount":0
			};
			var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
			oModelSelectionParameter.setData(selectionParameterdata);
			that.getOwnerComponent().setModel(oModelSelectionParameter, "ReportsModel");
			var oModel = that.getOwnerComponent().getModel("ReportsModel");
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");

			/***************** Personas Identified **************/

			dashboardModel.read("/AppsBasedSto3ResultSet", {
				urlParameters: {
					$select: 'Businessgroupdescription,Lob,Totalcount',
					$format: 'json'
				},
				success: function(oData, response) {

					var results = oData.results;
					// PersonaDetList = oData.results;
					var holder = {};
					var vlist = {};
					var vLoblist = {};
					var aList = [];
					var tempList = {};
					results.forEach(function(d) {

						if (vLoblist.hasOwnProperty(d.Lob)) {
							vLoblist[d.Lob] = vLoblist[d.Lob] + "," + d.Businessgroupdescription;
							var temp = vLoblist[d.Lob];
							var aLoblist = [];
							aLoblist = temp.split(",");
							var uniqueItems = Array.from(new Set(aLoblist));
							vLoblist[d.Lob] = uniqueItems;
						} else {
							vLoblist[d.Lob] = d.Businessgroupdescription;

						}
					});
					tempList = vLoblist;
					PersonaDetList = vLoblist;
					results.forEach(function(d) {

						if (vlist.hasOwnProperty(d.Businessgroupdescription)) {

							vlist[d.Businessgroupdescription] = vlist[d.Businessgroupdescription] + "," + d.Lob;

							var temp = vlist[d.Businessgroupdescription];

							aList = temp.split(",");
							var uniqueItems = Array.from(new Set(aList));
							vlist[d.Businessgroupdescription] = uniqueItems;

						} else {
							vlist[d.Businessgroupdescription] = d.Lob;

						}
					});

					results.forEach(function(d) {

						if (holder.hasOwnProperty(d.Businessgroupdescription)) {
							holder[d.Businessgroupdescription] = holder[d.Businessgroupdescription] + 1;

						} else {
							holder[d.Businessgroupdescription] = 1;

						}
					});

					oModel.getData().ListView = [];

					var piechartdata = [];
					for (var i = 0; i < Object.keys(vLoblist).length; i++) {
						oModel.getData().PieValue.push({
							Lob: Object.keys(vLoblist)[i],
							Totalcount: vLoblist[Object.keys(vLoblist)[i]].length,
							Personas: vLoblist[Object.keys(vLoblist)[i]]
						});
						oModel.getData().ListView.push({
							Lob: Object.keys(vLoblist)[i],
							Totalcount: vLoblist[Object.keys(vLoblist)[i]].length,
							Personas: vLoblist[Object.keys(vLoblist)[i]]
						});
						piechartdata.push({
							"Lob": Object.keys(vLoblist)[i],
							"PersonaCount": vLoblist[Object.keys(vLoblist)[i]].length
						});
					}
					oModel.getData().lobCount=Object.keys(vLoblist).length-1;
					var personas=Object.values(vLoblist).flat()
					var onlyUnique=function (value, index, self) {
					  return self.indexOf(value) === index;
					};
					oModel.getData().personaCount=(personas.filter(onlyUnique)).length;
					oModel.refresh();
					oModel.updateBindings();

					

				},
				error: function(oError) {

				}

			});
		}

	});
});