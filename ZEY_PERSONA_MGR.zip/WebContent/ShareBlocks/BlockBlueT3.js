sap.ui.define(['sap/uxap/BlockBase'],
	function (BlockBase) {
		"use strict";

		var BlockBlueT3 = BlockBase.extend("znav_routing.znav_routing.ShareBlocks.BlockBlueT3", {
			metadata: {
				views: {
					Collapsed: {
						viewName: "znav_routing.znav_routing.ShareBlocks.BlockBlueT3",
						type: "XML"
					},
					Expanded: {
						viewName: "znav_routing.znav_routing.ShareBlocks.BlockBlueT3",
						type: "XML"
					}
				}
			}
		});

		return BlockBlueT3;

	});