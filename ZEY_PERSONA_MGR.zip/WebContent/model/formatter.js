var total=0;
sap.ui.define([], function() {
	"use strict";

	return {

		statusColor: function(sValue) {
			if (sValue[0] === "*") {

				//	this.$().addClass("redColor");
				return "Error";

			} else {
				return "None";
			}

			//return sValue;
		},
		
		fioriExecTxt:function(sValue){
			return (sValue - (sValue * 20 /100)).toFixed() + " mins";
		},
		
		dollarSavingsPerOrder:function(orderId,oValue,flag){
			//debugger;
			var tcodeDollarValue =0;
            var fioriDollarValue =0;
            var dollarSavings;
            
			for(var i=0;i<oValue.results.length;i++){
                if(orderId===oValue.results[i].OrderId){
                tcodeDollarValue = tcodeDollarValue + parseInt(oValue.results[i].TransProcTime.split(' ')[0]);
                fioriDollarValue = fioriDollarValue + parseInt(oValue.results[i].Fioriproctime.split(' ')[0]);
             }
             }
            dollarSavings = (tcodeDollarValue * 0.833)- (fioriDollarValue * 0.833);
            if(flag=== null){
            	total= total + parseInt(dollarSavings.toFixed());
            	this.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel").setProperty('/totalSavings', total );
            }
            return "$ " +dollarSavings.toFixed();
            
			//console.log(oValue);
		}

	};

});