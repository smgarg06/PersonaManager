sap.ui.define(['sap/uxap/BlockBase'],
	function (BlockBase) {
		"use strict";

		var BlockBlueT5 = BlockBase.extend("fpm.FIORI_Persona_Manager.ShareBlocks.BlockBlueT5", {
			metadata: {
				views: {
					Collapsed: {
						viewName: "fpm.FIORI_Persona_Manager.ShareBlocks.BlockBlueT5",
						type: "XML"
					},
					Expanded: {
						viewName: "fpm.FIORI_Persona_Manager.ShareBlocks.BlockBlueT5",
						type: "XML"
					}
				}
			}
		});

		return BlockBlueT5;

	});