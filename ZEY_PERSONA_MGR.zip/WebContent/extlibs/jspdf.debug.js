.activationDashboardTileHeaderText {
	font-size: 1rem;
}

.activationDashboardTileHeaderTextValue {
	font-size: 2rem;
}

.activationDashboardPanel {
	background-color: #ffffff;
	border-radius: 5px;
}

.backgroundSolid {
	background-color: #2e2e38 !important;
}

.sapFDynamicPageTitle {
    z-index: 3;
    position: relative;
    min-height: 3rem;
    padding: 0.5rem 2rem 0.5rem 3rem;
    display: flex;
    display: -webkit-flex;
    flex-direction: column;
    -webkit-flex-direction: column;
    box-sizing: border-box;
    background: #2e2e38 !important;
}

.activationDashboardSection {
	background-image: url('../images/BG.jpg')
}

.assessmentAnalysis.sapMText {
	text-align: left;
    color: white;
    font-size: 1rem;
    margin-left: -21px;
}

#__section2-innerGrid.sapUiRespGrid.sapUiRespGridHSpace1 {
    padding: 0;
    margin-top: -30px;
    margin-left: -30px;
    margin-right: -30px;
}

.sapFDynamicPageTitle {
	z-index: 3;
    position: relative;
    min-height: 3rem;
    padding: 0.5rem 2rem 0.5rem 3rem;
    display: flex;
    display: -webkit-flex;
    flex-direction: column;
    -webkit-flex-direction: column;
    box-sizing: border-box;
    background: #2e2e38 !important;
}

.sapFDynamicPageHeader {
    z-index: 2;
    position: relative;
    -webkit-flex-shrink: 0;
    flex-shrink: 0;
    box-sizing: border-box;
    background: #ffffff !important;
}

.sapUxAPObjectPageNavigation {
    background: #ffffff !important;
}

.sapUxAPAnchorBar.sapMTB {
    border: none !important;
    background: #ffffff !important;
}

.sapUxAPObjectPageLayout .sapFDynamicPageToggleHeaderIndicator.sapMBtn>.sapMBtnInner {
    background-color: #ffffff !important;
    border-color: #5181b4 !important;
}

.sapFDynamicPageHeaderPinButton:hover>.sapMBtnInner.sapMBtnHoverable {
    background-color: #ffffff !important;
    border-color: #5181b4 !important;
}

.sapFDynamicPageHeaderPinButton .sapMBtnInner:not(.sapMToggleBtnPressed) {
    background-color: #ffffff !important;
    border-color: #5181b4 !important;
}

.tileTextClass {
	font-size: 0.8rem !important
}

.sapFDynamicPageHeader.sapFDynamicPageHeaderWithContent {
    padding: 1rem 3rem;
    box-shadow: 0 0rem 0 0 #ffffff, inset 0 -0.125rem 0 0 #e6e6e6 !important;
}

.sapFDynamicPageTitleMain>.sapFDynamicPageTitleMainInner .sapFDynamicPageTitleMainHeading .sapFDynamicPageTitleMainHeadingInner .sapMTitle {
    font-size: 1.25rem;
    color: #427cac;
} 

.headerBarFont.sapUiIcon {
    position: relative;
    cursor: default;
    text-align: center;
    display: inline-block;
    vertical-align: baseline;
    line-height: 1;
    color: #427cac;
}

.text1.sapMText {
	font-size: 1.5rem;
}

.label2.sapMLabel {
	font-size: 1rem;
}

.boxes {
	background-color: white !important;
	border-radius: 10px !important;
	border-bottom-color: #dfdfdf !important;
	border-top-color: #dfdfdf !important;
	border-left-color: #dfdfdf !important;
	border-right-color: #dfdfdf !important;
	border-left-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-top-style: solid;
    padding: 1rem;
}

.boxes2 {
	background-color: #2e2e38 !important;
	border-radius: 10px !important;
	border-bottom-color: #2e2e38 !important;
	border-top-color: #2e2e38 !important;
	border-left-color: #2e2e38 !important;
	border-right-color: #2e2e38 !important;
	border-left-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-top-style: solid;
    padding: 0rem;
}

.boxes3 {
	background-color: #333 !important;
	border-radius: 10px !important;
	border-bottom-color: #dfdfdf !important;
	border-top-color: #dfdfdf !important;
	border-left-color: #dfdfdf !important;
	border-right-color: #dfdfdf !important;
	border-left-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-top-style: solid;
    padding: 1rem;
}

.boxes4 {
    background-color: #dfdfdf !important;
    border-radius: 10px !important;
    border-bottom-color: #dfdfdf !important;
    border-top-color: #dfdfdf !important;
    border-left-color: #dfdfdf !important;
    border-right-color: #dfdfdf !important;
    border-left-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-top-style: solid;
    padding: 1rem;
}

.boxes5 {
    background-color: #cccccc7d !important;
    border-radius: 10px !important;
    border-bottom-color: #cccccc !important;
    border-top-color: #cccccc !important;
    border-left-color: #cccccc !important;
    border-right-color: #cccccc !important;
    border-left-style: solid;
    border-right-style: solid;
    border-bottom-style: solid;
    border-top-style: solid;
    padding: 1rem;
}

.chartTitle.sapMTitle {
	font-weight: 600;
}

.tCodesStyle.sapMTitle {
	font-size: 2rem;
}

.titleCustom.sapMTitle {
	text-shadow: 0 0 0rem #ffffff;
}

.blueColor {
	color: #1676d8 !important;
}

.greenColor {
	color: green !important;
}

.whiteColor {
	color: #ffffff !important;
}

.yelloColor {
	color: #ffe600 !important;
}

.personasTable {
	padding: 1.5rem !important;
}

.sapSuiteCpMCChartBar>div {
    height: 1.2rem !important;
    min-width: 0.25rem !important;
}

.sapSuiteCpMCChartContent.sapSuiteCpMCLookWide .sapSuiteCpMCChartItem {
    height: 0.875rem !important;
    margin-bottom: 1rem !important;
    align-items: center !important;
}

.sapSuiteCpMCChartContent.sapSuiteCpMCLookWide .sapSuiteCpMCChartItemTitle, .sapSuiteCpMCChartContent.sapSuiteCpMCLookWide .sapSuiteCpMCChartItemValue {
    top: 0 !important;
    margin-left: 0 !important;
    margin-bottom: -1rem !important;
}

.personasTable2.sapMLIB {
    display: -webkit-box;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    position: relative;
    background: #ffffff;
    border-bottom: 3px solid #e5e5e5; 
    padding: -1px 1rem 0 1rem;
}

.personasTable.sapMSticky>.sapMListHdrText, .sapMSticky>.sapMListHdrTBar.sapMTB-Transparent-CTX {
    background: #999999;
    font-size: 1.5rem;
    text-align: center;
}

.sapMPanelContent:not(.sapMPanelBGTransparent) {
    border-bottom: 0px solid #cccccc; 
}

.sapMSticky1>.sapMListHdr, .sapMSticky2>.sapMListInfoTBarContainer, .sapMSticky3>.sapMListHdr {
    top: 0;
    border-radius: 10px;
}

.link.sapMLnk {
    color: #fff;
    text-decoration: none;
    display: inline-block;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    word-wrap: normal;
    font-family: "72","72full",Arial,Helvetica,sans-serif;
    font-size: 1.2rem;
    cursor: pointer;
}

.panelHeader {
	font-size: 1.7rem !important;
	text-shadow: 0 0px 0 #ffffff !important;
    color: #ffe600 !important;
}

.sapMPanel>.sapMPanelHdr, .sapMPanelWrappingDiv, .sapMPanelWrappingDivTb {
    border-bottom: 1px solid #e2e2e2;
    background-color: #333;
    border-top: solid;
    border-bottom: 1 px solid #cccccc;
    /* border-top: 1px solid #cccccc; */
    /* border-left: 1px solid #cccccc; */
    /* border-right: 1px solid #cccccc; */
    border-radius: 10px;
    padding-bottom: 1rem;
    padding-top: 1rem;
}

.sapMPanelExpandableIcon {
    position: absolute;
    width: 1.7rem;
    line-height: 1.5rem;
    font-size: 1.5rem;
    margin: 0 0.75rem;
    top: 50%;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    color: #ffe600;
}

.sapUxAPObjectPageContainer, .sapUxAPObjectPageContainer + div, .sapUxAPObjectPageHeaderDetailsHidden {
    background-color: #2e2e38 !important;
    border-top-color: #2e2e38 !important;
}

.sapFDynamicPageTitleMain>.sapFDynamicPageTitleMainInner .sapFDynamicPageTitleMainHeading .sapFDynamicPageTitleMainHeadingInner .sapMTitle {
    font-size: 1.5rem !important;
    color: #ffe600 !important;
    text-shadow: none;
}

span.sapMBtnInner.sapMBtnEmphasized {
    background-image: none;
    background-color: #999999;
    border-color: #999999;
    color: #ffffff;
    text-shadow: 0 0 0.125rem rgba(0,0,0,0.5);
}

.sapMIBar.sapMHeader-CTX {
    color: #666666;
    background-color: #2e2e38;
    border-bottom: none;
    filter: none;
    background-image: none;
}

:not(.sapMBtnDisabled) .sapMBtnBack>.sapMBtnIcon, :not(.sapMBtnDisabled) .sapMBtnTransparent>.sapMBtnIcon, :not(.sapMBtnDisabled) .sapMBtnGhost>.sapMBtnIcon {
    color: #ffffff;
}

.tableText {
	color: #ffffff !important;	
}

.sapMListTblHeader>.sapMTableTH {
    background: #333;
    border-bottom: 1px solid #e5e5e5;
    background-clip: padding-box;
    vertical-align: middle;
}

.sapMListTbl .sapMText, .sapMListTbl .sapMLabel {
    font-size: 1rem;
    color: #ffe600;
    font-weight: normal;
}

.sapMRbBLabel {
    vertical-align: top;
    height: 3rem;
    line-height: 3rem;
    cursor: default;
    color: white !important;
}

.sapMList {
    position: relative;
    box-sizing: border-box;
    margin: 0;
    padding: 24px;
}

.sapMLIBShowSeparator>td {
    border-top: none;
}

.comparisonChartTitle {
	font-size: 1.3rem !important;
}
.clsWhiteBtn>span
{
	color : white !important;
}

.sapUxAPObjectPageContainer .sapMObjStatusNone:not(.sapMObjStatusInverted) .sapMObjStatusText, .sapUxAPObjectPageHeaderContentItem .sapMObjStatusNone:not(.sapMObjStatusInverted) .sapMObjStatusText, .sapMObjStatusNone:not(.sapMObjStatusInverted).sapUxAPObjectPageHeaderContentItem .sapMObjStatusText, .sapUxAPObjectPageHeaderDetails .sapFDynamicPageHeaderContent .sapMObjStatusNone:not(.sapMObjStatusInverted) .sapMObjStatusText, .sapUxAPObjectPageContainer .sapMObjStatusNone:not(.sapMObjStatusInverted) .sapMObjStatusIcon, .sapUxAPObjectPageHeaderContentItem .sapMObjStatusNone:not(.sapMObjStatusInverted) .sapMObjStatusIcon, .sapMObjStatusNone:not(.sapMObjStatusInverted).sapUxAPObjectPageHeaderContentItem .sapMObjStatusIcon, .sapUxAPObjectPageHeaderDetails .sapFDynamicPageHeaderContent .sapMObjStatusNone:not(.sapMObjStatusInverted) .sapMObjStatusIcon {
    color: #ffffff;
}

.sapMObjStatusError .sapMObjStatusText, .sapMObjStatusError .sapMObjStatusIcon {
    color: #ff0000;
    font-weight: 600;
}

.sapMLabel {
	color: #ffe600;
	font-size: 1rem;
}

.sapMListHdrText {
font-size: 1.3rem;
color: #fafafa;
background-color: #333;
	
}

.sapMIBar-CTX .sapMTitle {
    color: #ffe600;
}

.sapMTitleStyleAuto {
    font-size: 1.1rem;
}

.link.sapMLnk {
    color: #fff;
    text-decoration: underline;
}

.sapMIBar-CTX .sapMTitle {
    text-shadow: 0 0 0 #ffe600;
}

.sapMSLITitle, .sapMSLITitleOnly {
    font-size: 1rem;
    color: #ffe600;
}

.sapMList {
    position: relative;
    box-sizing: border-box;
    margin: 0;
    /* padding: 24px; */
}

/*.sapMFlexBoxAlignItemsStretch {
    block-size: 5rem;
}*/

.sapMLIB {
    display: -webkit-box;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    position: relative;
    background: #ffffff;
    border-bottom: 1px solid #2f3c48;
    padding: 0 1rem 0 1rem;
}

.sapContrast.sapMIBar.sapMFooter-CTX {
    background-color: #17181900 !important;
    border-top: 1px solid #475b6d;
}

.sapMText {
   font-size: 0.95rem;
}

.sapMLIBHoverable {
	  background-color:  #ffe600 ;
}


.backgroundSolid {
	/*background-color: #edf0f3 !important;*/
}

.headerBarFont.sapUiIcon {
    position: relative;
    cursor: default;
    text-align: center;
    display: inline-block;
    vertical-align: baseline;
    line-height: 1;
    color: #427cac;
}

.boxBackgroundDark {
	background-color: rgb(59, 56, 56);
}

.yellowFont {
	color: rgb(255, 192, 0) !important;
}

.orangeFont {
	color: orange !important;
}

.panelClass {
	border-top: solid 2px rgb(255, 192, 0) ;
	border-bottom: solid 2px rgb(255, 192, 0) ;
	border-right: solid 2px rgb(255, 192, 0) ;
	border-left: solid 2px rgb(255, 192, 0) ;
}

.sapFDynamicPageTitle {
    z-index: 2;
    position: relative;
    min-height: 3rem;
    padding: 0.5rem 2rem 0.5rem 3rem;
    display: flex;
    display: -webkit-flex;
    flex-direction: column;
    -webkit-flex-direction: column;
    box-sizing: border-box;
    background: #2e2e38 !important;
}

.sapMShellBrandingBar {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 4px;
    z-index: 1;
    background-color: #2e2e38 !important;
}
