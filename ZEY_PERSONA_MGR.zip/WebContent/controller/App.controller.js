var fioriAppsSelected = [];
var fioriAppsSelectedObjectList  = [];
sap.ui.define([
   "sap/ui/core/mvc/Controller"
], function (Controller) {
   "use strict";
   return Controller.extend("fpm.FIORI_Persona_Manager.controller.App", {
   	
   		onInit : function()
   		{
				var dashboardModel = this.getOwnerComponent().getModel("DashboardFirstScreenModel");
					dashboardModel.read("/SaveCartSet",{
						success: function(oData) {
								if(oData.results.length > 0)
								{
									var dataSet = JSON.parse(oData.results[0].Cartitm);
									fioriAppsSelected = dataSet.fioriAppsSelected;
									fioriAppsSelectedObjectList = dataSet.fioriAppsSelectedObjectList;
								}
								
										},
						error: function() {
										}
					});
   		}
			
   });
});