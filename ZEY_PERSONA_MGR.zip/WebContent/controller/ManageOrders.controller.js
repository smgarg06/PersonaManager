sap.ui.define(["sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/suite/ui/microchart/InteractiveBarChartBar",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"  ,
	"fpm/FIORI_Persona_Manager/model/formatter",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	
//	"fpm/FIORI_Persona_Manager/extlibs/jspdf.debug",
	"fpm/FIORI_Persona_Manager/extlibs/jspdf.plugin.autotable"

], function(Controller, Filter, FilterOperator, InteractiveBarChartBar, JSONModel, MessageBox,formatter) {
	"use strict";

	var that;
	var oRouter;

	jQuery.sap.require("sap.ui.core.routing.Router");
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.ManageOrders", {
		formatter: formatter,
		onInit: function() {
			that = this;
			this.getSplitAppObj().setHomeIcon({
				'phone': 'phone-icon.png',
				'tablet': 'tablet-icon.png',
				'icon': 'desktop.ico'
			});
			var selectionParameterdata = {
				"AllOrders": [],
				"AllOrdersList": [],
				"OrderAppDetails": [],
				"TotalOrders": []
			};

			var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
			oModelSelectionParameter.setData(selectionParameterdata);
			that.getOwnerComponent().setModel(oModelSelectionParameter, "ManageOrdersSelectionParameterModel");

			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("ManageOrders").attachPatternMatched(this.onLoadData, this);

		},
		
		onLoadData: function() {

			that.getView().byId("masterList").setBusy(true);
			that.getView().byId("detail").setBusy(true);
			var dashboardModel = this.getOwnerComponent().getModel("DashboardFirstScreenModel");
			var selParamModel = this.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			// if(selParamModel.getData().createdOrderId!==null){
			// 	that.onOrderIDPressed(selParamModel.getData().createdOrderId);
			// 	that.getView().byId("masterList").setModel(that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel"));
			// 	that.getView().byId("masterList").setBusy(false);
			// }else{
			dashboardModel.read("/OrderCartSet", {
				urlParameters: {
					$expand: 'OrderstoDetails',
					$format: 'json'
				},
				success: function(oData) {
					if (oData.results.length > 0) {

						var oModel = that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel");

						var orderId = oData.results[0].ORDERID;
						oModel.setProperty("/TotalOrder", oData.results.length);
						oModel.setProperty("/SelectedOrder", orderId);
					//	var vCartItems = JSON.parse(oData.results[0].CARTITM);
						var vCartItems = oData.results[0].OrderstoDetails.results;
						oModel.getData().OrderAppDetails = vCartItems;
						oModel.setProperty("/CreatedBy", oData.results[0].CREATEDBY);
						/*var  date = JSON.stringify(oData.results[0].CREATEDON);
						var vCreatedOn = date.slice(1,11);*/
						var date = oData.results[0].CREATEDON;
						var dateString = new Date(date).toLocaleDateString();
						oModel.setProperty("/CreatedOn", dateString);
						oModel.setProperty("/LastChangedBy", oData.results[0].LASTCHANGEDBY);
						/*	var  date1 = JSON.stringify(oData.results[0].LASTCHANGEDON);
							var vLastCreatedOn = date1.slice(1,11);*/
						var date1 = oData.results[0].LASTCHANGEDON;
						var vLastCreatedOn = new Date(date1).toLocaleDateString();
						oModel.setProperty("/LastChangedOn", vLastCreatedOn);
						that.getView().byId("detail").setBusy(false);
						
						oModel.getData().AllOrdersList = oData.results;
						oModel.refresh();
						oModel.updateBindings();
						var dollarSavingVal=formatter.dollarSavingsPerOrder(orderId,oData.results[0].OrderstoDetails,false);                         
						that.getView().byId("dollarSavingsLayout").getItems()[1].getItems()[0].setText(dollarSavingVal);
						that.getView().byId("masterList").setModel(that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel"));
						that.getView().byId("masterList").setBusy(false);
						that.ordersHeaderContent(orderId);
						if(selParamModel.getData().createdOrderId!==null){
							that.onOrderIDPressed(selParamModel.getData().createdOrderId);
						}

					}

				},
				error: function() {
					that.getView().byId("masterList").setBusy(false);
					that.getView().byId("detail").setBusy(false);
				}
			});
		//	}
			

		},
		
			onHome: function() {

			oRouter.navTo("ActivationDashboard");
			},
		
		ordersHeaderContent:function(vOrderId){
			var dashboardModel = this.getOwnerComponent().getModel("DashboardFirstScreenModel");
			//var oModel= new sap.ui.model.odata.v2.ODataModel("https://10.0.122.68:8001/sap/opu/odata/SAP/ZFIORI_PERSONAMGR_SRV/Get_OrderDetails?OrderID='" + vOrderId +"'");
			dashboardModel.callFunction("/Get_OrderDetails", {
				method: "GET",
				urlParameters: {
					"OrderID": vOrderId,
					$format: 'json'
					
				},
				success: function(oData) {
					var PotentialSavingsModel= new JSONModel();
					that.getOwnerComponent().setModel(PotentialSavingsModel,"PotentialSavingsModel");
					//var oModel = that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel");
					PotentialSavingsModel.setData(oData.Get_OrderDetails);
					//oModel.getData().PotentialSavings = oData.Get_OrderDetails;
					var FioriExecTime=	(oData.Get_OrderDetails.Tcodeexecutiontime -oData.Get_OrderDetails.Tcodeexecutiontime * 20 /100).toFixed();
					that.getView().byId("detail").getContent()[3].getItems()[3].getItems()[0].setText(FioriExecTime + " Mins");
					PotentialSavingsModel.refresh();
					PotentialSavingsModel.updateBindings();
					
				},
				error: function() {
					that.getView().byId("masterList").setBusy(false);
					that.getView().byId("detail").setBusy(false);
				}
			});
		},

		onGoToViewCart: function() {

			oRouter.navTo("ViewCart");
			//window.history.back();
			
			// oRouter.navTo("AssignAdminDashboard", {
			// 	businessGroupDescription: that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").getProperty("/BusinessGroupDescription")
			// });

		},

		_printReport: function() {
			var doc = new jsPDF('p', 'pt', 'letter');
			var stabId = document.getElementById(this.getView().byId("appDescription").getId()).children[2].getAttribute('id');
			var tabsId = doc.autoTableHtmlToJson(document.getElementById(stabId));
			//doc.addHTML(document.getElementById('__hbox3'));
			doc.autoTable(tabsId.columns, tabsId.data, {
				startY: 50,
				pageBreak: 'auto',
				tableWidth: 'auto',
				styles: {
					overflow: 'linebreak',
					columnWidth: 'wrap'
				},
				headStyles: {
					0: {
						halign: 'center',
						fillColor: [0, 255, 0]
					}
				},
				beforePageContent: function(data) {
					doc.setTextColor('#2e2e38');
					doc.text("Assessment Report - Fiori Apps List", 40, 40);
				}
			});
			doc.save('Assessment Report' + '.pdf');
			
		},

		onPressNavToDetail: function() {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack: function() {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack: function() {
			this.getSplitAppObj().backMaster();
		},

		onPressGoToMaster: function() {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},

		onListItemPress: function(oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn: function(oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageBox.show("Split Container mode is changed to: " + sSplitAppMode, {
				duration: 5000
			});
		},

		getSplitAppObj: function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				MessageBox.show("SplitApp object can't be found");
			}
			return result;
		},
		onOrderIDPressed: function(oEvent) {
			var vOrderId;
			if(typeof oEvent !== "string"){
				vOrderId	= oEvent.getSource().mProperties.title;
			}else{
				vOrderId = this.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").getData().createdOrderId;
				
			}
			 
			var dashboardModel = this.getOwnerComponent().getModel("DashboardFirstScreenModel");
			that.getView().byId("detail").setBusy(true);
			dashboardModel.read("/OrderCartSet('" + vOrderId + "')", {
				urlParameters: {
					$expand: 'OrderstoDetails',
					$format: 'json'
				},
				success: function(oData) {

					var oModel = that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel");
					oModel.setProperty("/SelectedOrder", vOrderId);
					oModel.setProperty("/CreatedBy", oData.CREATEDBY);

					var date = oData.CREATEDON;
					var dateString = new Date(date).toLocaleDateString();
					oModel.setProperty("/CreatedOn", dateString);
					oModel.setProperty("/LastChangedBy", oData.LASTCHANGEDBY);
					var date1 = oData.LASTCHANGEDON;
					var dateString1 = new Date(date1).toLocaleDateString();
					oModel.setProperty("/LastChangedOn", dateString1);

					//var vCartItems = JSON.parse(oData.CARTITM);
					var vCartItems = oData.OrderstoDetails.results;
					oModel.getData().OrderAppDetails = vCartItems;
					that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").setProperty('/createdOrderId', null);
					oModel.refresh();
					oModel.updateBindings();
					that.ordersHeaderContent(vOrderId);
					var dollarSavingVal=formatter.dollarSavingsPerOrder(vOrderId,oData.OrderstoDetails,false);                         
					that.getView().byId("dollarSavingsLayout").getItems()[1].getItems()[0].setText(dollarSavingVal);
					that.getView().byId("detail").setBusy(false);

				},
				error: function() {
					that.getView().byId("detail").setBusy(false);
				}
			});
		},
		createColumnConfig: function() {
			return [{
				label: 'Order ID',
				property: 'OrderID',
				scale: 50
			}, {
				label: 'Created By',
				property: 'CreatedBy',
				width: '50'
			}, {
				label: 'Created On',
				property: 'CreatedOn',
				width: '25'
			}, {
				label: 'App ID',
				property: 'AppID',
				width: '10'
			}, {
				label: 'App Name',
				property: 'AppName',
				width: '108'
			}, {
				label: 'Persona Name',
				property: 'PersonaName',
				width: '108'
			}];
		},
		onDataExport: sap.m.Table.prototype.exportData || function() {
			
			var dashboardModel = this.getOwnerComponent().getModel("DashboardFirstScreenModel");
			
			var selOrder=that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel").getData().SelectedOrder;
			dashboardModel.read("/OrderCartSet", {
				urlParameters: {
					$expand: 'OrderstoDetails',
					$format: 'json'
				},
				success: function(oData) {
					if (oData.results.length > 0) {

						var oModel = that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel");
						oModel.getData().TotalOrders = [];

						for (var i = 0; i < oData.results.length; i++) {
							var orderId = oData.results[i].ORDERID;
							var cartItem = JSON.parse(oData.results[i].CARTITM);

							for (var j = 0; j < cartItem.length; j++) {
								if(selOrder){
									if(selOrder===orderId){
									oModel.getData().TotalOrders.push({
									'Orderid': orderId,
									'Appid': cartItem[j].Appid,
									'Appname': cartItem[j].Appname,
									'BusinessGroupDescription': cartItem[j].BusinessGroupDescription,
									'SystemAlias':"LOCAL",
									'CreatedBy': oData.results[i].CREATEDBY,
									'CreatedOn': oData.results[i].CREATEDON,
									'LastChangedBy': oData.results[i].LASTCHANGEDBY,
									'LastChangedOn': oData.results[i].LASTCHANGEDON
								});
								}
								}
								
								
							}

						}
						var JsonData = {
							items: oModel.getData().TotalOrders
						};
						var oExport = new sap.ui.core.util.Export({

							exportType: new sap.ui.core.util.ExportTypeCSV({
								separatorChar: "\t",

								mimeType: "application/vnd.ms-excel",

								charset: "utf-8",

								fileExtension: "xls"
							}),

							models: oModel,

							rows: {
								path: "/TotalOrders"
							},
							columns: [{
								name: "Order ID",
								template: {
									content: "{Orderid}"
								}
							}, {
								name: "Created By",
								template: {
									content: "{CreatedBy}"
								}
							}, {
								name: "Created On",
								template: {
									content: "{CreatedOn}"
								}
							}, {
								name: "Appname",
								template: {
									content: "{Appname}"
								}
							}, {
								name: "BusinessGroupDescription",
								template: {
									content: "{BusinessGroupDescription}"
								}
							},{
								name: "SystemAlias",
								template: {
									content: "{SystemAlias}"
								}
							}, {
								name: "LastChangedBy",
								template: {
									content: "{LastChangedBy}"
								}
							}, {
								name: "LastChangedOn",
								template: {
									content: "{LastChangedOn}"
								}
							}]
						});
						console.log(oExport);
						oExport.saveFile("OrderDetails").catch(function(oError) {

						}).then(function() {
							oExport.destroy();
						});

						oModel.refresh();
						oModel.updateBindings();
						// that.getView().byId("masterList").setModel(that.getOwnerComponent().getModel("ManageOrdersSelectionParameterModel"));
						//that.getView().byId("appDescription").setBusy(false);
					}

				},
				error: function() {
					//	that.getView().byId("appDescription").setBusy(false);
				}
			});
		}

	});
});