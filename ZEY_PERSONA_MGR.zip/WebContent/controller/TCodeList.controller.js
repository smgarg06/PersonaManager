sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"

], function(Controller, JSONModel, MessageBox, History) {
	"use strict";
	var oRouter;
	var that;
	var clicks = 0;
	var num = 0;
	var count1;

	jQuery.sap.require("sap.ui.core.routing.Router");
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.TCodeList", {

		onInit: function() {
			that = this;

			var oVizFrameFrequency = this.oVizFrameFrequency = this.getView().byId("idChartFrequency");
			oVizFrameFrequency.setVizProperties({
				legend: {
					visible: false
				},
				categoryAxis: {
					title: {
						visible: false,
					}
				},
				title: {
					visible: true,
					text: "Top 10 Mostly Used Transactions"
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "percentage"
					},
					colorPalette: ["#ffe600",'#333333','sapUiChartPaletteSemanticCritical','#ffffff','#cccccc','#999999','#52575D', 'sapUiChartPaletteSemanticCriticalLight3','sapUiChartPaletteSemanticNeutral','sapUiChartPaletteSemanticCriticalDark2','#FFD000']
				},
				tooltip: {
					bodyMeasureValue: {
						type: "valueAndPercentage"
					},
					visible: true,
					formatString: "1234"
				}
			});

			var oVizFrameResponseTime = this.oVizFrameFrequency = this.getView().byId("idChartResponseTime");
			oVizFrameResponseTime.setVizProperties({
				legend: {
					visible: false
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: true,
					text: "Top 10 Transactions by Least Average Response Time (in seconds)"
				},
				plotArea: {
					colorPalette: ['#ffe600'],
					gridline: {
						visible: false
					}
				},
				tooltip: {
					bodyMeasureValue: {
						color: "#ffffff"
					},
					visible: true,
					formatString: "1234"
				}
			});

			that.getView().byId("idPopOverFrequency").connect(that.getView().byId("idChartFrequency").getVizUid());

			var oTooltipFrequency = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipFrequency.connect(that.getView().byId("idChartFrequency").getVizUid());

			that.getView().byId("idPopOverResponseTime").connect(that.getView().byId("idChartResponseTime").getVizUid());

			var oTooltipResponseTime = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipResponseTime.connect(that.getView().byId("idChartResponseTime").getVizUid());

			var selectionParameterdata = {
				// "TCodesIdentifiedNew": [],
				// "TCodesIdentifiedFrequencyChart": [],
				// "TCodesIdentifiedResponseTimeChart": []
			};
			var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
			oModelSelectionParameter.setData(selectionParameterdata);
			that.getOwnerComponent().setModel(oModelSelectionParameter, "TCodesListModel");
			that.onLoadTCodeUsages();

		},

		handleFormatSeconds: function(milliseconds) {

			var avgResponseTime;

			var seconds = Math.round(parseFloat(milliseconds) / 1000);

			if (seconds.toString().length < 3) {
				avgResponseTime = Math.round(seconds, 2) + " " + "secs";
			} else if (seconds.toString().length === 3) {
				avgResponseTime = Math.round((seconds / 60), 2) + " " + "mins";
			} else if (seconds.toString().length > 3) {
				avgResponseTime = Math.round(((seconds / 60) / 60), 2) + " " + "hrs";
			}

			if (isNaN(seconds)) {
				avgResponseTime = "";
			}

			return avgResponseTime;

		},

		onSelectTCode: function(oEvent) {

			if (oEvent.getSource().mProperties.hasOwnProperty("selectedKey") === true) {
				that.getView().byId("idTCodesCancelIcon").setVisible(true);
			} else {
				that.getView().byId("idTCodes").setSelectedKey();
				that.getView().byId("idTCodesCancelIcon").setVisible(false);
			}

			that.onLoadTCodes();
		},

		onTCodesLiveSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter1 = new Filter("TCODE", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter1]);
		},

		onLoadTCodes: function() {

			var oModel = that.getOwnerComponent().getModel("TCodesListModel");
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");

			that.getView().byId("tcodeTable").setBusy(true);
			that.getView().byId("idChartFrequency").setBusy(true);
			that.getView().byId("idChartResponseTime").setBusy(true);

			that.getView().byId("totalTCodesText").setBusy(true);
			that.getView().byId("customTCodesText").setBusy(true);
			that.getView().byId("standardTCodesText").setBusy(true);

			/************** Set TCode List Screen ****************/

			dashboardModel.read("/AppIdForTcodeSet", {
				urlParameters: {
					$select: 'Tcode,AvgResponseTime,Totalcount',
					$format: 'json',
				},
				success: function(oData, response) {

					oModel.getData().TCodesIdentifiedNew = [];
					oModel.getData().TCodesIdentifiedFrequencyChart = [];

					var count = oData.results.length;
					//count1 = count - 6;

					var allTCodes = [];

					var finalTCodes = [];
					var customTCodes = 0;

					for (var i = 0; i < oData.results.length; i++) {
						var found = allTCodes.find(element => element == oData.results[i].Tcode);

						if (found === undefined) {
							allTCodes.push(oData.results[i].Tcode);
							finalTCodes.push({
								TCODE: oData.results[i].Tcode,
								// Frequency: oData.results[i].Totalcount,
								Frequency: 20,
								// AvgResponseTime: (parseFloat(oData.results[i].AvgResponseTime) / 1000),
								// AvgResponseTimeParsed: that.handleFormatSeconds(oData.results[i].AvgResponseTime)
								AvgResponseTime: (parseFloat(oData.results[i].AvgResponseTime * 20 ) / 1000),
								AvgResponseTimeParsed: that.handleFormatSeconds(oData.results[i].AvgResponseTime * 20)
							});
							if (oData.results[i].Tcode[0] === "Z" || oData.results[i].Tcode[0] === "Y") {
								customTCodes = customTCodes + 1;
							}
						} else {
							 //finalTCodes[finalTCodes.map(function(e) {
							 //	return e.TCODE;
							 //}).indexOf(found)].Frequency = parseInt(finalTCodes[finalTCodes.map(function(e) {
							 //	return e.TCODE;
							 //}).indexOf(found)].Frequency)+1;
						}
					}

					var finalTCodesFrequency = finalTCodes.slice().sort(function compare_item(a, b) {
						if (a.Frequency > b.Frequency) {
							return -1;
						} else if (a.Frequency < b.Frequency) {
							return 1;
						} else {
							return 0;
						}
					});

					var finalTCodesResponseTime = finalTCodes.slice().sort(function compare_item(a, b) {
						if (a.AvgResponseTime < b.AvgResponseTime) {
							return -1;
						} else if (a.AvgResponseTime > b.AvgResponseTime) {
							return 1;
						} else {
							return 0;
						}
					});

					oModel.getData().TCodesIdentifiedNew = finalTCodesFrequency;
					oModel.getData().TCodesIdentifiedFrequencyChart = finalTCodesFrequency.slice(0, 10);
					oModel.getData().TCodesIdentifiedResponseTimeChart = finalTCodesResponseTime.slice(0, 10);

					oModel.setProperty("/TotalTCodesText", finalTCodes.length);
					oModel.setProperty("/CustomTCodesText", customTCodes);
					oModel.setProperty("/StandardTCodesText", parseInt(finalTCodes.length - customTCodes));

					oModel.refresh();
					oModel.updateBindings();

					that.getView().byId("tcodeTable").setBusy(false);
					that.getView().byId("idChartFrequency").setBusy(false);
					that.getView().byId("idChartResponseTime").setBusy(false);

					that.getView().byId("totalTCodesText").setBusy(false);
					that.getView().byId("customTCodesText").setBusy(false);
					that.getView().byId("standardTCodesText").setBusy(false);

				},
				error: function(oError) {

				}
			});
		},

		onLoadTCodeUsages: function() {
			var selectedTCode = that.getView().byId("idTCodes").getSelectedKey();
			var filters = [];
			if (selectedTCode !== "") {
				filters.push(new sap.ui.model.Filter("TCODE", sap.ui.model.FilterOperator.EQ, selectedTCode));
			}

			var oModel = that.getOwnerComponent().getModel("TCodesListModel");
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");

			that.getView().byId("tcodeTable").setBusy(true);
			that.getView().byId("idChartFrequency").setBusy(true);
			that.getView().byId("idChartResponseTime").setBusy(true);

			that.getView().byId("totalTCodesText").setBusy(true);
			that.getView().byId("customTCodesText").setBusy(true);
			that.getView().byId("standardTCodesText").setBusy(true);

			dashboardModel.read("/AppIdForTcodeSet", {
				urlParameters: {
					$select: 'Tcode,AvgResponseTime,Totalcount',
					$format: 'json'
				},
				filters: filters,
				success: function(oData, response) {

					oModel.getData().TCodesIdentifiedNew = [];
					oModel.getData().TCodesIdentifiedFrequencyChart = [];

					if (that.getView().byId("tcodesType").getSelectedIndex() === 0) {
						// Do Nothing
					} else if (that.getView().byId("tcodesType").getSelectedIndex() === 1) {
						var resultTemp = oData.results.filter(function(el) {
							return el.Tcode[0] != 'Z' &&
								el.Tcode[0] != 'Y';
						});
						oData.results = resultTemp;
					} else if (that.getView().byId("tcodesType").getSelectedIndex() === 2) {
						var resultTemp = oData.results.filter(function(el) {
							return el.Tcode[0] == 'Z' ||
								el.Tcode[0] == 'Y';
						});
						oData.results = resultTemp;
					}

					var count = oData.results.length;

					var allTCodes = [];

					var finalTCodes = [];
					var customTCodes = 0;

					for (var i = 0; i < oData.results.length; i++) {
						var found = allTCodes.find(element => element == oData.results[i].Tcode);

						if (found === undefined) {
							allTCodes.push(oData.results[i].Tcode);
							finalTCodes.push({
								TCODE: oData.results[i].Tcode,
								// Frequency: oData.results[i].Totalcount,
								// AvgResponseTime: (parseFloat(oData.results[i].AvgResponseTime) / 1000),
								// AvgResponseTimeParsed: that.handleFormatSeconds(oData.results[i].AvgResponseTime)
								Frequency: 20,
								AvgResponseTime: (parseFloat(oData.results[i].AvgResponseTime * 20 ) / 1000),
								AvgResponseTimeParsed: that.handleFormatSeconds(oData.results[i].AvgResponseTime * 20 )
							});
							if (oData.results[i].Tcode[0] === "Z" || oData.results[i].Tcode[0] === "Y") {
								customTCodes = customTCodes + 1;
							}
						} else {
							// finalTCodes[finalTCodes.map(function(e) {
							// 	return e.TCODE;
							// }).indexOf(found)].Frequency = parseInt(finalTCodes[finalTCodes.map(function(e) {
							// 	return e.TCODE;
							// }).indexOf(found)].Frequency) + 1;
						}
					}

					var finalTCodesFrequency = finalTCodes.slice().sort(function compare_item(a, b) {
						if (a.Frequency > b.Frequency) {
							return -1;
						} else if (a.Frequency < b.Frequency) {
							return 1;
						} else {
							return 0;
						}
					});

					var finalTCodesResponseTime = finalTCodes.slice().sort(function compare_item(a, b) {
						if (a.AvgResponseTime < b.AvgResponseTime) {
							return -1;
						} else if (a.AvgResponseTime > b.AvgResponseTime) {
							return 1;
						} else {
							return 0;
						}
					});

					oModel.getData().TCodesIdentifiedNew = finalTCodesFrequency;
					oModel.getData().TCodesIdentifiedFrequencyChart = finalTCodesFrequency.slice(0, 10);
					oModel.getData().TCodesIdentifiedResponseTimeChart = finalTCodesResponseTime.slice(0, 10);

					oModel.setProperty("/TotalTCodesText", finalTCodes.length);
					oModel.setProperty("/CustomTCodesText", customTCodes);
					oModel.setProperty("/StandardTCodesText", parseInt(finalTCodes.length - customTCodes));

					that.getView().byId("tcodeTable").setBusy(false);
					that.getView().byId("idChartFrequency").setBusy(false);
					that.getView().byId("idChartResponseTime").setBusy(false);
					that.getView().byId("totalTCodesText").setBusy(false);
					that.getView().byId("customTCodesText").setBusy(false);
					that.getView().byId("standardTCodesText").setBusy(false);

					oModel.refresh();
					oModel.updateBindings();

				},
				error: function(oError) {

				}
			});
		},

		onNavBack: function() {

			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ActivationDashboard");
		}
	});
});