sap.ui.define(["sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"sap/suite/ui/microchart/InteractiveBarChartBar",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"fpm/FIORI_Persona_Manager/model/formatter"

], function(Controller, Filter, FilterOperator, InteractiveBarChartBar, JSONModel, MessageBox, formatter) {
	"use strict";

	var that;
	var oRouter;
	var selectedDuetoSearchUsers = [];
	var retrievedTCodes = [];

	var fioriAppsSelectedObjectList = [];
	var fioriAppsSelected = [];

	jQuery.sap.require("sap.ui.core.routing.Router");
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.AssignAdminDashboard", {
		formatter: formatter,
		onInit: function() {
			that = this;
			oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//that.getOwnerComponent().setProperty("loadedFlag",0);
			oRouter.getRoute("AssignAdminDashboard").attachPatternMatched(this.onLoadData, this);
			//oModel.setProperty("/SelectedApps",0);

		},

		onLoadData: function(oEvent) {
			// if condition added to load data from the cache while navigating back from other screens rather than making call to the server each and every time
			if (!that.loadedFlag || that.loadedFlag !==oEvent.getParameter("arguments").businessGroupDescription) {

				var selectionParameterdata = {
					"Users": [],
					"ProvisionedUsers": [],
					"AppDescription": [],
					"AppDescriptionOthers": [],
					"TCodeDetailsByCurrentApp": [],
					"AddedCart": []
				};

				var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
				oModelSelectionParameter.setData(selectionParameterdata);
				that.getOwnerComponent().setModel(oModelSelectionParameter, "AssignAdminSelectionParameterModel");
				
				that.onLoadTCodes();
				that.loadedFlag=oEvent.getParameter("arguments").businessGroupDescription;
				oModelSelectionParameter.setProperty("/SelectedApps", fioriAppsSelected.length);
				// fioriAppsSelectedObjectList=[];
				// fioriAppsSelected=[];
				// that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").setProperty("/SelectedApps", 0);
			}
		
		},

		onLoadTCodes: function() {
			var urlParams = window.location.href.split('/');
			var businessGroupDescription = urlParams[urlParams.length - 1];
			businessGroupDescription = businessGroupDescription.replace(/%20/g, " ");
			//temporary code
			var tempBGDescr;
						if(businessGroupDescription==="Without Process Assignment(Standard)"){
							tempBGDescr = "";
						}else{
							tempBGDescr=businessGroupDescription
						}
			
			for (var i = 0; i < businessGroupDescription.length; i++) {
				if (businessGroupDescription.charAt(0) === " ") {
				//	businessGroupDescription = businessGroupDescription.slice(1);
				} else {
					break;
				}
			}

			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			oModel.setProperty("/BusinessGroupDescription", businessGroupDescription);
			
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
			
			var filters = [new sap.ui.model.Filter("Businessgroupdescription", sap.ui.model.FilterOperator.EQ, tempBGDescr)];
			that.getView().byId("appDescription").setBusy(true);
			that.getView().byId("tcodeTable").setBusy(true);
			that.getView().byId("appDescriptionOthers").setBusy(true);
			
			if(businessGroupDescription==="Without Process Assignment(Custom)"){
				that.getView().getContent()[0].getContent()[0].setShowHeaderContent(false);
			}
			else{
				that.getView().getContent()[0].getContent()[0].setShowHeaderContent(true);
			}

			dashboardModel.read("/AppIdForTcodeSet", {
				urlParameters: {
					$format: 'json'
				},
				filters: filters,
				success: function(oData, response) {

					var allTCodes = [];

					var finalTCodes = [];
					var customTCodes = 0;

					var totalResponseTimeTCode = 0;
					var totalFrequencyTCode = 0;
					var counter = 0;

					for (var i = 0; i < oData.results.length; i++) {
						var found = allTCodes.find(element => element == oData.results[i].Tcode);

						if (found === undefined) {
							allTCodes.push(oData.results[i].Tcode);
							retrievedTCodes = allTCodes;
							finalTCodes.push({
								Tcode: oData.results[i].Tcode,
								Frequency: 1,
								AvgResponseTime: (parseFloat(oData.results[i].AvgResponseTime * 20) /*/ 1000*/),
								AvgResponseTimeParsed: that.handleFormatSeconds(oData.results[i].AvgResponseTime * 20),
								Appid: oData.results[i].Appid
							});

							counter = counter + 1;
							if (!isNaN(parseFloat(oData.results[i].AvgResponseTime))) {
								totalResponseTimeTCode = (totalResponseTimeTCode + parseFloat(oData.results[i].AvgResponseTime * 20));
							}
							if (oData.results[i].Tcode[0] === "Z" || oData.results[i].Tcode[0] === "Y") {
								customTCodes = customTCodes + 1;
							}
						} else {
							finalTCodes[finalTCodes.map(function(e) {
								return e.Tcode;
							}).indexOf(found)].Frequency = 20;/*parseInt(finalTCodes[finalTCodes.map(function(e) {
								return e.Tcode;
							}).indexOf(found)].Frequency) + 1;*/
						}

					}

					for (var i = 0; i < finalTCodes.length; i++) {
						totalFrequencyTCode = totalFrequencyTCode + finalTCodes[i].Frequency;
					}

					var averageResponseTimeTCode = Math.round((parseFloat(totalResponseTimeTCode / counter).toFixed(2)) / 1000);

					that.getView().byId("avgTimeTCodes").setValue(parseFloat(averageResponseTimeTCode));
					//that.getView().byId("avgTimeTCodes").setDisplayValue(parseFloat(averageResponseTimeTCode) + " sec");

					that.getView().byId("freqTimeTCodes").setValue(parseInt(finalTCodes.length));
					that.getView().byId("freqTimeTCodes").setDisplayValue(parseInt(finalTCodes.length));

					oModel.getData().TCodeDetailsByCurrentApp = finalTCodes;

					oModel.getData().AppDescription = [];
					var results = oData.results;

					const map = new Map();

					var totalResponseTimeAppId = 0;
					var counter = 0;

					var allFioriApps = [];
					var TcodeExecutionTime;

					for (var i = 0; i < results.length; i++) {

						var found = allFioriApps.find(element => element == oData.results[i].Appid);

						if (found === undefined) {

							//var avgTime = Math.floor(Math.random() * (10 - 5 + 1) + 5);
							//var avgTime = Math.floor(Math.random() * (10 - 5 + 1) + 5);
							var TcodeArr=finalTCodes;
							 TcodeExecutionTime= (TcodeArr.reduce(function(prev, cur) {
											  return prev + parseInt((cur.AvgResponseTime ).toFixed());
											}, 0));
							var avgTime=TcodeExecutionTime - (TcodeExecutionTime * 20 /100);
							if ($.inArray(results[i].Appid, allFioriApps) === -1) {
								//if(lob===oData.results[i].lob){
									allFioriApps.push(oData.results[i].Appid);
								oModel.getData().AppDescription.push({
									Appid: oData.results[i].Appid,
									Appname: oData.results[i].Appname,
									//FioriAvgResponseTime: (avgTime * 20) + " sec"
									FioriAvgResponseTime: that.handleFormatSeconds(avgTime ),
								});
								totalResponseTimeAppId = totalResponseTimeAppId + parseFloat(avgTime);
								counter = counter + 1;
								//}
								
							}

						} else {
							if ($.inArray(results[i].Appid, allFioriApps) === -1) {
								//if(lob===oData.results[i].lob){
								oModel.getData().AppDescription.push({
									Appid: oData.results[i].Appid,
									Appname: oData.results[i].Appname,
									FioriAvgResponseTime: ""
								});
								//}
							}

						}
					}

					var averageResponseTimeAppId = parseFloat(totalResponseTimeAppId / counter).toFixed(2);

					that.getView().byId("avgTimeApps").setValue(parseFloat(averageResponseTimeAppId));
					// that.getView().byId("avgTimeApps").setDisplayValue(parseFloat(averageResponseTimeAppId) + " sec");
					// that.getView().byId("avgTimeTCodes").setDisplayValue(parseFloat(TcodeExecutionTime) + " sec");
					that.getView().byId("avgTimeApps").setDisplayValue(that.handleFormatSeconds(averageResponseTimeAppId  ));
					that.getView().byId("avgTimeTCodes").setDisplayValue(that.handleFormatSeconds(TcodeExecutionTime));

					that.getView().byId("freqTimeApps").setValue(counter);
					that.getView().byId("freqTimeApps").setDisplayValue(counter);
					
					if(businessGroupDescription==="Without Process Assignment(Custom)"){
						that.getView().byId("avgTimeApps").setValue(null);
						that.getView().byId("avgTimeApps").setDisplayValue(null);
						// that.getView().byId("avgTimeTCodes").setValue(null);
						// that.getView().byId("avgTimeTCodes").setDisplayValue(null);
						that.getView().byId("freqTimeApps").setValue(null);
						that.getView().byId("freqTimeApps").setDisplayValue(null);
						//that.getView().getContent()[0].getContent()[0].setShowHeaderContent(false);
						// that.getView().byId("freqTimeTCodes").setValue(null);
						// that.getView().byId("freqTimeTCodes").setDisplayValue(null);
						oModel.getData().AppDescription=null;
					}else{
						//that.getView().getContent()[0].getContent()[0].setShowHeaderContent(true);
					}

					oModel.refresh();
					oModel.updateBindings();

					that.onLoadFioriAppsOthers();
				},
				error: function(oError) {

				}
			});

		},

		onLoadFioriAppsOthers: function() {

			var urlParams = window.location.href.split('/');
			var businessGroupDescription = urlParams[urlParams.length - 1];
			businessGroupDescription = businessGroupDescription.replace(/%20/g, " ");
			//temporary code
			var tempBGDescr;
						if(businessGroupDescription==="Without Process Assignment(Standard)"){
							tempBGDescr = "";
						}else{
							tempBGDescr=businessGroupDescription
						}
			var allTCodes = [];
			for (var i = 0; i < retrievedTCodes.length; i++) {
				allTCodes.push(new sap.ui.model.Filter("Tcode", sap.ui.model.FilterOperator.NE, retrievedTCodes[i]));
			}
			
			var lob=that.getOwnerComponent().getModel("PersonaListModel").getData().selLOB;
			if(lob==="Others"){
				lob="Without LOB Assignment";
			}
			//allTCodes.push(new sap.ui.model.Filter("Lob", sap.ui.model.FilterOperator.EQ, lob));
			var filters = [new Filter(allTCodes, true)];

			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
			
			dashboardModel.read("/AppsBasedonPersonaLobSet", {
				urlParameters: {
					$format: 'json'
				},
				filters: filters,
				success: function(oData, response) {

					oModel.getData().AppDescriptionOthers = [];
					var results = oData.results;

					const map = new Map();

					var totalResponseTimeAppId = 0;
					var counter = 0;

					var allFioriApps = [];
					var appIdRecommended;
					if(tempBGDescr==="Without Process Assignment(Custom)"){
						appIdRecommended="";
					}else{
						appIdRecommended=oModel.getData().AppDescription[0].Appid;
					}
					
					for (var i = 0; i < results.length; i++) {

						var found = allFioriApps.find(element => element == oData.results[i].Appid);

						if (found === undefined) {

							var avgTime = Math.floor(Math.random() * (10 - 5 + 1) + 5);

							if ($.inArray(results[i].Appid, allFioriApps) === -1) {
								allFioriApps.push(oData.results[i].Appid);
								if(lob===oData.results[i].Lob && tempBGDescr.replace("  ","")===oData.results[i].Businessgroupdescription){
									if(appIdRecommended!==oData.results[i].Appid){
								oModel.getData().AppDescriptionOthers.push({
									Appid: oData.results[i].Appid,
									Appname: oData.results[i].Appname,
									//FioriAvgResponseTime: avgTime * 20 + " sec"
									FioriAvgResponseTime: that.handleFormatSeconds(avgTime * 20)
								});
								totalResponseTimeAppId = totalResponseTimeAppId + parseFloat(avgTime);
								counter = counter + 1;
							}
							}
							}

						} else {
							//if ($.inArray(results[i].Appid, allFioriApps) === -1) {
								if(lob===oData.results[i].Lob && tempBGDescr.replace("  ","")===oData.results[i].Businessgroupdescription){
									if(appIdRecommended!==oData.results[i].Appid){
								oModel.getData().AppDescriptionOthers.push({
									Appid: oData.results[i].Appid,
									Appname: oData.results[i].Appname,
									FioriAvgResponseTime: ""
								});
									}
							}
							//}

						}
					}

					var averageResponseTimeAppId = parseFloat(totalResponseTimeAppId / counter).toFixed(2);

					// that.getView().byId("avgTimeApps").setValue(parseFloat(averageResponseTimeAppId));
					// that.getView().byId("avgTimeApps").setDisplayValue(parseFloat(averageResponseTimeAppId) + " sec");

					// that.getView().byId("freqTimeApps").setValue(counter);
					// that.getView().byId("freqTimeApps").setDisplayValue(counter);
					
					if(businessGroupDescription==="Without Process Assignment(Custom)"){
						oModel.getData().AppDescriptionOthers=null;
					}
					
					that.getView().byId("appDescriptionOthers").setModel(oModel);
					that.getView().byId("appDescription").setBusy(false);
					that.getView().byId("tcodeTable").setBusy(false);
					that.getView().byId("appDescriptionOthers").setBusy(false);

					oModel.refresh();
					oModel.updateBindings();

					that.onLoadExistingUsers();
				},
				error: function(oError) {

				}
			});

		},

		handleFormatSeconds: function(milliseconds) {

			var avgResponseTime;

			var seconds = Math.round(parseFloat(milliseconds) / 1000);

			if (seconds.toString().length < 3) {
				avgResponseTime = Math.round(seconds, 2) + " " + "secs";
			} else if (seconds.toString().length === 3) {
				avgResponseTime = Math.round((seconds / 60), 2) + " " + "mins";
			} else if (seconds.toString().length > 3) {
				avgResponseTime = Math.round(((seconds / 60) / 60), 2) + " " + "hrs";
			}

			if (isNaN(seconds)) {
				avgResponseTime = "";
			}

			return avgResponseTime;

		},
    	onHome: function() {

			oRouter.navTo("ActivationDashboard");
			},
		onFioriAppsSelect: function(oEvent) {
			var selectedFlag = oEvent.getSource().getSelected();
			var selectedApp = oEvent.getSource().getText();

			that.getView().byId("actionSheet").removeAllButtons();

			var indexValofApp = jQuery.inArray(selectedApp, fioriAppsSelected);
			if (selectedFlag === true) {
				if (indexValofApp === -1) {
					var TcodeArr= that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").getData().TCodeDetailsByCurrentApp;
					for (var i=0;i<TcodeArr.length;i++){
					var obj = new Object();
					obj.OrderId="";
					obj.FioriAppId = oEvent.getSource().getBindingContext('AssignAdminSelectionParameterModel').getObject().Appid;
					obj.Fioriappname = oEvent.getSource().getBindingContext('AssignAdminSelectionParameterModel').getObject().Appname;
					obj.Processname = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").getData().BusinessGroupDescription;
					obj.Tcode=TcodeArr[i].Tcode;
					obj.TransProcTime=(TcodeArr[i].AvgResponseTime).toFixed();
					//obj.TcodeCount= that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel").getData().TCodeDetailsByCurrentApp.length;
					
					
					//var average = TcodeArr.reduce((total, next) => total + next.AvgResponseTime, 0) / TcodeArr.length;
					//obj.TcodeExecutionTime= average.toFixed();
					// obj.TcodeExecutionTime= (TcodeArr.reduce(function(prev, cur) {
					// 						  return prev + parseInt((cur.AvgResponseTime).toFixed());
					// 						}, 0));
					//obj.FioriExecutionTime=obj.TcodeExecutionTime - (obj.TcodeExecutionTime * 20 /100);
					fioriAppsSelectedObjectList.push(obj);
					
					// for (var i=0;i<TcodeArr.length;i++){
					// 	for(var j=0;j<fioriAppsSelectedObjectList.length;j++){
					// 	if(TcodeArr[i].Appid===fioriAppsSelectedObjectList[j].FioriAppId){
					// 		//fioriAppsSelectedObjectList.push(fioriAppsSelectedObjectList[j]);
					// 		fioriAppsSelectedObjectList[j].Tcode = TcodeArr[i].Tcode;
					// 		fioriAppsSelectedObjectList[j].TransProcTime=TcodeArr[i].AvgResponseTime;
					// 		fioriAppsSelectedObjectList.push(fioriAppsSelectedObjectList[j]);
					// 	}
					// 	}
					// }
				}
				fioriAppsSelected.push(selectedApp);
				}

			} else {
				 var index = fioriAppsSelected.indexOf(selectedApp);
				// fioriAppsSelected.splice(index, 1);
				// fioriAppsSelectedObjectList.splice(index, 1);
				
				for(var i=0;i<fioriAppsSelectedObjectList.length;i++){
					if(fioriAppsSelected[index]===fioriAppsSelectedObjectList[i].FioriAppId){
					        fioriAppsSelectedObjectList.splice(i,1);
					        
					        i--;
					}
					}
				fioriAppsSelected.splice(index, 1);
			}
			
			var unique = [...new Set(fioriAppsSelectedObjectList.map(item => item.FioriAppId))]; // return unique Fiori app Id from the selected list

			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			oModel.setProperty("/SelectedApps", unique.length);
			oModel.getData().AddedCart = fioriAppsSelectedObjectList;

		},

		onOpenSelectedApps: function(oEvent) {
			oRouter.navTo("ViewCart");
		},

		onLoadExistingUsers: function() {

			that.getView().byId("provisionedUsers").setBusy(true);
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
			dashboardModel.read("/RoleAssignmentSet", {
				urlParameters: {
					$format: 'json'
				},
				success: function(oData, response) {

					var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
					oModel.getData().ProvisionedUsers = oData.results;

					that.getView().byId("provisionedUsers").setModel(oModel);

					oModel.refresh();
					oModel.updateBindings();

					that.getView().byId("provisionedUsers").setBusy(false);

				}.bind(this),
				error: function(oError) {

				}
			});
		},

		onOpenUserList: function(oEvent) {

			that.getView().setBusy(true);
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
			dashboardModel.read("/UserDetailsVHSet", {
				urlParameters: {
					$format: 'json'
				},
				success: function(oData, response) {

					var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
					oModel.getData().Users = oData;

					if (!that._oDialog) {
						that._oDialog = sap.ui.xmlfragment("fpm.FIORI_Persona_Manager.fragment.AddUsers", that);
					}
					that._oDialog.setModel(oModel);

					jQuery.sap.syncStyleClass("sapUiSizeCompact", that.getView(), that._oDialog);
					that._oDialog.open();

					oModel.refresh();
					oModel.updateBindings();

					that.getView().setBusy(false);

				}.bind(this),
				error: function(oError) {

				}
			});
		},

		onUsersLiveSearch: function(Evt) {
			var sValue = Evt.getParameter("value");
			var oFilter1 = new Filter("Uname", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = Evt.getSource().getBinding("items");
			Evt.getSource().getItems().filter(function(i) {
				if (i.getSelected()) {
					selectedDuetoSearchUsers.push(i.getTitle())
				}
			});
			oBinding.filter([oFilter1]);
		},

		onUsersValueHelpConfirm: function(Evt) {

			var aSelectedItems = Evt.getParameter("selectedItems");
			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");

			for (var i = 0; i < aSelectedItems.length; i++) {

				var selectedItem = aSelectedItems[i].getTitle();

				if ((selectedDuetoSearchUsers.findIndex(i => i.Uname === selectedItem)) === -1) {
					selectedDuetoSearchUsers.push({
						Uname: aSelectedItems[i].getTitle(),
						FullName: aSelectedItems[i].getDescription()
					});
				}

				if ((oModel.getData().ProvisionedUsers.findIndex(i => i.Uname === selectedItem)) === -1) {
					oModel.getData().ProvisionedUsers.push({
						Uname: aSelectedItems[i].getTitle(),
						FullName: aSelectedItems[i].getDescription()
					});
				}
			}

			that.getView().byId("provisionedUsers").setModel(oModel);

			oModel.refresh();
			oModel.updateBindings();

			selectedDuetoSearchUsers = [];

		},

		onUsersClose: function() {
			that._oDialog.close();
		},

		onUsersBulkUpload: function(e) {

			var fileLoader = this.getView().byId("fileUploader");

			that.getView().byId("provisionedUsers").setBusy(true);

			var fU = that.getView().byId("idfileUploader");
			var domRef = fU.getFocusDomRef();
			var file = domRef.files[0];
			var dublicateValue = [];
			try {

				var excelData = {};
				if (file && window.FileReader) {
					var reader = new FileReader();
					reader.onload = function(e) {
						var data = e.target.result;
						var workbook = XLSX.read(data, {
							type: 'binary'
						});
						workbook.SheetNames.forEach(function(sheetName) {
							// Here is your object for every sheet in workbook
							excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);

						});

						var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
						dashboardModel.read("/UserDetailsVHSet", {
							urlParameters: {
								$format: 'json'
							},
							success: function(oData, response) {

								var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
								oModel.getData().Users = oData;

								oModel.getData().ProvisionedUsers = [];

								var unmatchedUserIDs = [];

								for (var i = 0; i < excelData.length; i++) {
									var pos = oModel.getData().Users.results.map(function(e) {
										return e.Uname;
									}).indexOf(excelData[i].UserID);

									if (pos === -1) {
										unmatchedUserIDs.push(excelData[i].UserID);

										oModel.getData().ProvisionedUsers.push({
											Uname: "*" + excelData[i].UserID,
											FullName: "*" + excelData[i].UserName
										});
									} else {
										oModel.getData().ProvisionedUsers.push({
											Uname: excelData[i].UserID,
											FullName: excelData[i].UserName
										});
									}

								}

								oModel.refresh();
								oModel.updateBindings();
								that.getView().byId("provisionedUsers").setBusy(false);

								if (unmatchedUserIDs.length > 0) {
									MessageBox.error(
										"Some user(s) is/are not configured in the system. Please delete the user(s) marked in red before provisioning"
									);
								}
							},
							error: function(oError) {

							}
						});

					};
					reader.onerror = function(ex) {
						console.log(ex);
					};
					reader.readAsBinaryString(file);
				}

			} catch (Exception) {
				sap.m.MessageBox.error("File upload failed");
				that._oBusyDialog.close();
			}

		},

		onDeleteUser: function(oEvent) {
			var oModel = that.getOwnerComponent().getModel("AssignAdminSelectionParameterModel");
			var index = parseInt(oEvent.getSource().getId().charAt(oEvent.getSource().getId().length - 1));
			oModel.getData().ProvisionedUsers.splice(index, 1);
			oModel.refresh();
			oModel.updateBindings();
		},

		onGoToAdminConfigDashboard: function() {

			//localStorage.removeItem("loadedFlag");
			oRouter.navTo("PersonaList");

		},

		/*	saveCartEachTime: function(that) {
				if (fioriAppsSelected.length > 0) {
					var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");
					var oEntry = {};
					oEntry.Userid = 'X';
					oEntry.Cartitm = JSON.stringify({
						"fioriAppsSelected": fioriAppsSelected,
						"fioriAppsSelectedObjectList": fioriAppsSelectedObjectList
					});
					dashboardModel.create("/SaveCartSet", oEntry, {
						success: function() {},
						error: function() {}
					});
				}
			}*/

	});
});