sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"

], function(Controller, JSONModel, MessageBox, History) {
	"use strict";

	var that;
	var PersonaDetList = {};
	jQuery.sap.require("sap.ui.core.routing.Router");
	return Controller.extend("fpm.FIORI_Persona_Manager.controller.PersonaList", {
		onInit: function() {
			that = this;
			var oVizFrameFrequency = this.oVizFrameFrequency = this.getView().byId("idChartFrequencyLob");
			oVizFrameFrequency.setVizProperties({
				legend: {
					visible: true
				},
				legendGroup: {
					layout: {
						position: 'right',
						width: '40%'
					},
					linesOfWrap: 3
				},
				categoryAxis: {
					title: {
						visible: true
					}
				},
				title: {
					visible: true,
					text: "Process Count By Line of Business"
				},
				plotArea: {
					dataLabel: {
						visible: true,
						type: "percentage"
					},
					colorPalette: ["sapUiChartPaletteSemanticCritical", '#333333', '#ffe600', '#ffffff', '#cccccc', '#999999', '#52575D',
						'sapUiChartPaletteSemanticCriticalLight3', 'sapUiChartPaletteSemanticNeutral', 'sapUiChartPaletteSemanticCriticalDark2',
						'#FFD000'
					]
				},
				tooltip: {
					bodyMeasureValue: {
						type: "valueAndPercentage"
					},
					visible: true,
					formatString: "1234"
				},
				interaction: {
					selectability: {
						mode: "SINGLE"
					}
				}
			});
			var oTooltipPieLob = new sap.viz.ui5.controls.VizTooltip({});
			oTooltipPieLob.connect(that.getView().byId("idChartFrequencyLob").getVizUid());

			var selectionParameterdata = {
				"ListView": [],
				"PieValue": [],
				"selLOB":""
			};
			var oModelSelectionParameter = new sap.ui.model.json.JSONModel();
			oModelSelectionParameter.setData(selectionParameterdata);
			that.getOwnerComponent().setModel(oModelSelectionParameter, "PersonaListModel");
			that.onLoadPersonaList();

		},

		onClickPersona: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			that.getOwnerComponent().getModel("PersonaListModel").getData().selLOB=oEvent.getSource().getParent().getParent().getParent().getHeaderToolbar().getContent()[0].getText();
			oRouter.navTo("AssignAdminDashboard", {
				businessGroupDescription: oEvent.getSource().getText()
			});
		},
		
		onPanelExpand:function(oEvent){
			//console.log(oEvent.getSource());
			//that.getOwnerComponent().getModel("PersonaListModel").getData().selLOB = oEvent.getSource().getHeaderToolbar().getContent()[0].getText();
		},

		onLoadPersonaList: function() {

			var oModel = that.getOwnerComponent().getModel("PersonaListModel");
			var dashboardModel = that.getOwnerComponent().getModel("DashboardFirstScreenModel");

			that.getView().byId("personasTable").setBusy(true);
			that.getView().byId("idChartFrequencyLob").setBusy(true);

			/***************** Personas Identified **************/

			dashboardModel.read("/AppsBasedSto3ResultSet", {
				urlParameters: {
					$select: 'Businessgroupdescription,Lob,Totalcount',
					$format: 'json'
				},
				success: function(oData, response) {

					var results = oData.results;
					// PersonaDetList = oData.results;
					var holder = {};
					var vlist = {};
					var vLoblist = {};
					var aList = [];
					var tempList = {};
					results.forEach(function(d) {
						
						//temporary code
						if(d.Businessgroupdescription===""){
							d.Businessgroupdescription = "Without Process Assignment(Standard)";
						}else if(d.Businessgroupdescription==="Without Persona Assignment(Custom)"){
							d.Businessgroupdescription="Without Process Assignment(Custom)"
						}
						
						if(d.Lob==="Without LOB Assignment"){
							d.Lob="Others";
						}
						if (vLoblist.hasOwnProperty(d.Lob)) {
							
							vLoblist[d.Lob] = vLoblist[d.Lob] + "," + d.Businessgroupdescription;
							var temp = vLoblist[d.Lob];
							var aLoblist = [];
							aLoblist = temp.split(",");
							var uniqueItems = Array.from(new Set(aLoblist));
							vLoblist[d.Lob] = uniqueItems;
						} else {
						
							vLoblist[d.Lob] = d.Businessgroupdescription;

						}
					});
					tempList = vLoblist;
					PersonaDetList = vLoblist;
					results.forEach(function(d) {
						//temporary code
						if(d.Businessgroupdescription===""){
							d.Businessgroupdescription = "Without Process Assignment(Standard)";
						}
						if (vlist.hasOwnProperty(d.Businessgroupdescription)) {

							vlist[d.Businessgroupdescription] = vlist[d.Businessgroupdescription] + "," + d.Lob;

							var temp = vlist[d.Businessgroupdescription];

							aList = temp.split(",");
							var uniqueItems = Array.from(new Set(aList));
							vlist[d.Businessgroupdescription] = uniqueItems;

						} else {
							vlist[d.Businessgroupdescription] = d.Lob;

						}
					});

					results.forEach(function(d) {
						//temporary code
						if(d.Businessgroupdescription===""){
							d.Businessgroupdescription = "Without Process Assignment(Standard)";
						}else if(d.Businessgroupdescription==="Without Persona Assignment(Custom)"){
							d.Businessgroupdescription="Without Process Assignment(Custom)"
						}
						if (holder.hasOwnProperty(d.Businessgroupdescription)) {
							holder[d.Businessgroupdescription] = holder[d.Businessgroupdescription] + parseInt(d.Totalcount);

						} else {
							holder[d.Businessgroupdescription] = parseInt(d.Totalcount);

						}
					});

					oModel.getData().ListView = [];

					var piechartdata = [];
					for (var i = 0; i < Object.keys(vLoblist).length; i++) {
						// if(d.Lob==="Without LOB Assignment"){
						// 	d.Lob="Others";
						// }
						oModel.getData().PieValue.push({
							Lob: Object.keys(vLoblist)[i],
							Totalcount: vLoblist[Object.keys(vLoblist)[i]].length,
							Personas: vLoblist[Object.keys(vLoblist)[i]]
						});
						oModel.getData().ListView.push({
							Lob: Object.keys(vLoblist)[i],
							Totalcount: vLoblist[Object.keys(vLoblist)[i]].length,
							Personas: vLoblist[Object.keys(vLoblist)[i]]
						});
						piechartdata.push({
							"Lob": Object.keys(vLoblist)[i],
							"PersonaCount": vLoblist[Object.keys(vLoblist)[i]].length
						});
					}

					oModel.refresh();
					oModel.updateBindings();

					that.getView().byId("personasTable").setBusy(false);
					that.getView().byId("idChartFrequencyLob").setBusy(false);

				},
				error: function(oError) {

				}

			});
		},

		onLobSelect: function(oEvent) {

			var filters = [];

			if (oEvent.getId() === "deselectData") {
				// Do Nothing
			} else if (oEvent.getId() === "selectData") {

				var selectedLob = oEvent.getParameter("data")[0].data.Lob;
				var oModel = that.getOwnerComponent().getModel("PersonaListModel");
				var vLoblist = PersonaDetList;
				oModel.getData().ListView = [];

				for (var i = 0; i < Object.keys(vLoblist).length; i++) {
					if (Object.keys(vLoblist)[i] === selectedLob) {
						oModel.getData().ListView.push({
							Lob: Object.keys(vLoblist)[i],
							Totalcount: vLoblist[Object.keys(vLoblist)[i]].length,
							Personas: vLoblist[Object.keys(vLoblist)[i]]
						});
					}
				}
				oModel.updateBindings();
				oModel.refresh();

			}

		},

		onLobDeSelect: function (oEvent) {
			
			var oModel = that.getOwnerComponent().getModel("PersonaListModel");
			var vLoblist = PersonaDetList;
			oModel.getData().ListView = [];

			for (var i = 0; i < Object.keys(vLoblist).length; i++) {

				oModel.getData().ListView.push({
					Lob: Object.keys(vLoblist)[i],
					Totalcount: vLoblist[Object.keys(vLoblist)[i]].length,
					Personas: vLoblist[Object.keys(vLoblist)[i]]
				});

			}
			oModel.updateBindings();
			oModel.refresh();
		},

		onNavBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ActivationDashboard");
		}
	});
});